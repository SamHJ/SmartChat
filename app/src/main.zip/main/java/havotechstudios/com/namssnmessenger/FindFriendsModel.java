package havotechstudios.com.namssnmessenger;

public class FindFriendsModel {

    public String profileimage, fullname, username, school;

    public FindFriendsModel(){

        //required empty constructor
    }

    public FindFriendsModel(String profileimage, String fullname, String username, String school)
    {
        this.profileimage = profileimage;
        this.fullname = fullname;
        this.username = username;
        this.school = school;
    }

    public String getProfileimage() {
        return profileimage;
    }

    public void setProfileimage(String profileimage) {
        this.profileimage = profileimage;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUserschool() {
        return school;
    }

    public void setUserschool(String school) {
        this.school = school;
    }
}
