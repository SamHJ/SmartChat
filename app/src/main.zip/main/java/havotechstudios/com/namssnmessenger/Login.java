package havotechstudios.com.namssnmessenger;

import android.app.ActivityOptions;
import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.github.ybq.android.spinkit.style.FoldingCube;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GetTokenResult;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import es.dmoral.toasty.Toasty;

public class Login extends AppCompatActivity {
TextView login_recover_text;
TextView login_register_text, google_sign_in_text;
Button login_btn;
EditText login_email;
EditText login_password;
FirebaseAuth mAuth;
ProgressDialog loadingBar;
private static final int RC_SIGN_IN = 1;
GoogleApiClient mGoogleSignInClient;
private static final String TAG = "Login";
DatabaseReference usersRef;
FirebaseFirestore firebaseFirestore;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mAuth = FirebaseAuth.getInstance();
        usersRef = FirebaseDatabase.getInstance().getReference().child("Users");

        firebaseFirestore = FirebaseFirestore.getInstance();
        //init views
        login_recover_text = findViewById(R.id.login_recover_password);
        login_register_text = findViewById(R.id.login_register_here_text);
        login_btn = findViewById(R.id.btn_login);
        login_email = findViewById(R.id.login_input_email);
        login_password = findViewById(R.id.login_input_password);
        loadingBar = new ProgressDialog(this);
        google_sign_in_text = findViewById(R.id.google_sign_in_text);




        //google sign in functionality
        google_sign_in_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                performGoogleSignIn();
            }
        });

        //login_recover_text click listener
        login_recover_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent recover = new Intent(getApplicationContext(), RecoverPassword.class);
                startActivity(recover);
                finish();
            }
        });

        //login_register_text click listener
        login_register_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent register = new Intent(getApplicationContext(), Register.class);
                startActivity(register);
                finish();
            }
        });

        //login btn click listener
        login_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            performLogin();
            }
        });

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();

        mGoogleSignInClient = new GoogleApiClient.Builder(this)
                .enableAutoManage(this, new GoogleApiClient.OnConnectionFailedListener() {
                    @Override
                    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

                        alertgooglesigninfailed();

                    }
                })
                .addApi(Auth.GOOGLE_SIGN_IN_API, gso)
                .build();
    }

    private void alertgooglesigninfailed(){
       //before inflating the custom alert dialog layout, we will get the current activity viewgroup
        ViewGroup viewGroup = findViewById(android.R.id.content);

        //then we will inflate the custom alert dialog xml that we created
        View dialogView = LayoutInflater.from(this).inflate(R.layout.error_dialog, viewGroup, false);


        //Now we need an AlertDialog.Builder object
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        //setting the view of the builder to our custom view that we already inflated
        builder.setView(dialogView);

        //finally creating the alert dialog and displaying it
        final AlertDialog alertDialog = builder.create();

        Button dialog_btn = (Button) dialogView.findViewById(R.id.buttonError);
        TextView success_text = (TextView) dialogView.findViewById(R.id.error_text);
        TextView success_title = (TextView) dialogView.findViewById(R.id.error_title);

        dialog_btn.setText("OK");
        success_title.setText("Error");
        success_text.setText("Google sign in was not successful.");

        // if the OK button is clicked, close the success dialog
        dialog_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });

        alertDialog.show();
    }

    private void performGoogleSignIn() {

        Intent signInItent = Auth.GoogleSignInApi.getSignInIntent(mGoogleSignInClient);
        startActivityForResult(signInItent, RC_SIGN_IN);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == RC_SIGN_IN){

            loadingBar.setTitle("Authenticating email");
            loadingBar.setMessage("Please wait while your google account is been authenticated.");
            loadingBar.show();
            loadingBar.setCanceledOnTouchOutside(false);


            GoogleSignInResult result = Auth.GoogleSignInApi.getSignInResultFromIntent(data);

            if(result.isSuccess()){
                GoogleSignInAccount account = result.getSignInAccount();
                 firebaseAuthWithGoogle(account);
            }
            else {
                alertgooglesigninfailed();
                loadingBar.dismiss();
            }

        }
    }

    private void firebaseAuthWithGoogle(GoogleSignInAccount acct){
        Log.d(TAG, "firebaseAuthWithGoogle: " + acct.getId());

        AuthCredential authCredential = GoogleAuthProvider.getCredential(acct.getIdToken(), null);
        mAuth.signInWithCredential(authCredential)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        if(task.isSuccessful()){
                            //task was successful

                            FirebaseInstanceId.getInstance().getInstanceId()
                                    .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
                                        @Override
                                        public void onComplete(@NonNull final Task<InstanceIdResult> task) {
                                            if(task.isSuccessful()){

                                                final String online_user_id = mAuth.getCurrentUser().getUid();
                                                final String DeviceToken = task.getResult().getToken();

                                                String current_user_id = mAuth.getCurrentUser().getUid();
                                                Map<String, Object> tokenMap = new HashMap<>();
                                                tokenMap.put("token_id", DeviceToken);
                                                firebaseFirestore.collection("Users").document(current_user_id)
                                                        .update(tokenMap);

                                                usersRef.child(online_user_id).child("device_token").setValue(DeviceToken)
                                                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                            @Override
                                                            public void onComplete(@NonNull Task<Void> task) {
                                                                if(task.isSuccessful()){
                                                                    sendUserToHomeActivity();
                                                                    loadingBar.dismiss();
                                                                    login_success_toast();
                                                                }
                                                            }
                                                        });


                                            }
                                        }
                                    });




                        }
                        else {
                            loadingBar.dismiss();
                            //task was not successful
                            String message = task.getException().toString();
                            //before inflating the custom alert dialog layout, we will get the current activity viewgroup
                            ViewGroup viewGroup = findViewById(android.R.id.content);

                            //then we will inflate the custom alert dialog xml that we created
                            View dialogView = LayoutInflater.from(Login.this).inflate(R.layout.error_dialog, viewGroup, false);


                            //Now we need an AlertDialog.Builder object
                            AlertDialog.Builder builder = new AlertDialog.Builder(Login.this);

                            //setting the view of the builder to our custom view that we already inflated
                            builder.setView(dialogView);

                            //finally creating the alert dialog and displaying it
                            final AlertDialog alertDialog = builder.create();

                            Button dialog_btn = (Button) dialogView.findViewById(R.id.buttonError);
                            TextView success_text = (TextView) dialogView.findViewById(R.id.error_text);
                            TextView success_title = (TextView) dialogView.findViewById(R.id.error_title);

                            dialog_btn.setText("OK");
                            success_title.setText("Error");
                            success_text.setText(message);
                            // if the OK button is clicked, close the success dialog
                            dialog_btn.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    alertDialog.dismiss();
                                }
                            });

                            alertDialog.show();

                            sendUserToLoginActivity();
                        }
                    }
                });
    }

    private void sendUserToLoginActivity() {

        Intent sendToLogin = new Intent(Login.this, Login.class);
        startActivity(sendToLogin);
    }

    private void login_success_toast() {
        Toasty.success(this,"Login Successful!", Toasty.LENGTH_LONG, true).show();
    }

    @Override
    protected void onStart() {
        super.onStart();

        FirebaseUser currentUser = mAuth.getCurrentUser();
        if(currentUser != null){
            //send user to home activity
            sendUserToHomeActivity();
        }
    }

    private void performLogin() {
        final String email_login, pass_login;
        email_login = login_email.getText().toString();
        pass_login = login_password.getText().toString();

        if(email_login.isEmpty() || pass_login.isEmpty() ){
            showErrorCustomDialog();
        }
        else {
            if(validateEmail(email_login)) {

                    //perform login
                loadingBar.setTitle("A moment please");
                loadingBar.setMessage("Please wait while you are been logged in.");
                loadingBar.show();
                loadingBar.setCanceledOnTouchOutside(false);

                    mAuth.signInWithEmailAndPassword(email_login, pass_login)
                            .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                   if (task.isSuccessful()){


                                       final String online_user_id = mAuth.getCurrentUser().getUid();
                                       FirebaseInstanceId.getInstance().getInstanceId()
                                               .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
                                                   @Override
                                                   public void onComplete(@NonNull Task<InstanceIdResult> task) {
                                                       if(task.isSuccessful()){
                                                           final String DeviceToken = task.getResult().getToken();

                                                           String current_user_id = mAuth.getCurrentUser().getUid();
                                                           Map<String, Object> tokenMap = new HashMap<>();
                                                           tokenMap.put("token_id", DeviceToken);
                                                           firebaseFirestore.collection("Users").document(current_user_id)
                                                                   .update(tokenMap);

                                                           usersRef.child(online_user_id).child("device_token").setValue(DeviceToken)
                                                                   .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                                       @Override
                                                                       public void onSuccess(Void aVoid) {
                                                                           sendUserToHomeActivity();
                                                                           loadingBar.dismiss();
                                                                       }
                                                                   });

                                                       }
                                                   }
                                               });



                                   }
                                   else {
                                       String message = task.getException().getMessage();
                                       //{.....................
                                       //before inflating the custom alert dialog layout, we will get the current activity viewgroup
                                       ViewGroup viewGroup = findViewById(android.R.id.content);

                                       //then we will inflate the custom alert dialog xml that we created
                                       View dialogView = LayoutInflater.from(Login.this).inflate(R.layout.error_dialog, viewGroup, false);


                                       //Now we need an AlertDialog.Builder object
                                       AlertDialog.Builder builder = new AlertDialog.Builder(Login.this);

                                       //setting the view of the builder to our custom view that we already inflated
                                       builder.setView(dialogView);

                                       //finally creating the alert dialog and displaying it
                                       final AlertDialog alertDialog = builder.create();

                                       Button dialog_btn = (Button) dialogView.findViewById(R.id.buttonError);
                                       TextView success_text = (TextView) dialogView.findViewById(R.id.error_text);
                                       TextView success_title = (TextView) dialogView.findViewById(R.id.error_title);

                                       dialog_btn.setText("OK");
                                       success_title.setText("Error");
                                       success_text.setText(message);

                                       // if the OK button is clicked, close the success dialog
                                       dialog_btn.setOnClickListener(new View.OnClickListener() {
                                           @Override
                                           public void onClick(View v) {
                                               alertDialog.dismiss();
                                           }
                                       });

                                       alertDialog.show();
                                       //...................}

                                       loadingBar.dismiss();
                                   }
                                }
                            });

                    //startActivity(new Intent(getApplicationContext(), UserHome.class));

            }
            else {
                //display invalid email error
                invalid_email_address_erro_CustomDialog();
            }
        }
    }



    private void sendUserToHomeActivity() {
        Intent userhomeIntent = new Intent(getApplicationContext(), UserHome.class);
        startActivity(userhomeIntent);
        finish();
    }

    private boolean validateEmail(String data){
        Pattern emailPattern = Pattern.compile(".+@.+\\.[a-z]+");
        Matcher emailMatcher = emailPattern.matcher(data);
        return emailMatcher.matches();
    }

    private void showErrorCustomDialog() {
        //before inflating the custom alert dialog layout, we will get the current activity viewgroup
        ViewGroup viewGroup = findViewById(android.R.id.content);

        //then we will inflate the custom alert dialog xml that we created
        View dialogView = LayoutInflater.from(this).inflate(R.layout.error_dialog, viewGroup, false);


        //Now we need an AlertDialog.Builder object
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        //setting the view of the builder to our custom view that we already inflated
        builder.setView(dialogView);

        //finally creating the alert dialog and displaying it
        final AlertDialog alertDialog = builder.create();

        Button dialog_btn = (Button) dialogView.findViewById(R.id.buttonError);
        TextView success_text = (TextView) dialogView.findViewById(R.id.error_text);
        TextView success_title = (TextView) dialogView.findViewById(R.id.error_title);

        dialog_btn.setText("OK");
        success_title.setText("Error");
        success_text.setText("Your login was not successful! Make sure all fields are filled up correctly or check your internet connection.");

        // if the OK button is clicked, close the success dialog
        dialog_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });

        alertDialog.show();


    }

    private void invalid_email_address_erro_CustomDialog() {
        //before inflating the custom alert dialog layout, we will get the current activity viewgroup
        ViewGroup viewGroup = findViewById(android.R.id.content);

        //then we will inflate the custom alert dialog xml that we created
        View dialogView = LayoutInflater.from(this).inflate(R.layout.error_dialog, viewGroup, false);


        //Now we need an AlertDialog.Builder object
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        //setting the view of the builder to our custom view that we already inflated
        builder.setView(dialogView);

        //finally creating the alert dialog and displaying it
        final AlertDialog alertDialog = builder.create();

        Button dialog_btn = (Button) dialogView.findViewById(R.id.buttonError);
        TextView success_text = (TextView) dialogView.findViewById(R.id.error_text);
        TextView success_title = (TextView) dialogView.findViewById(R.id.error_title);

        dialog_btn.setText("OK");
        success_title.setText("Error");
        success_text.setText("Your E-mail address is invalid! Fix it and try again.");

        // if the OK button is clicked, close the success dialog
        dialog_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });

        alertDialog.show();


    }
}
