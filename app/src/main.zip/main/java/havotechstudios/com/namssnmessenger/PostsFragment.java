package havotechstudios.com.namssnmessenger;


import android.app.ActivityOptions;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.annotation.UiThread;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.view.MenuItemCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.util.Log;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.support.v7.widget.Toolbar;
import android.widget.Toast;
import android.widget.VideoView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Callback;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import de.hdodenhof.circleimageview.CircleImageView;
import es.dmoral.toasty.Toasty;

import static android.os.Environment.DIRECTORY_DOWNLOADS;


/**
 * A simple {@link Fragment} subclass.
 */
public class PostsFragment extends Fragment {
    com.github.clans.fab.FloatingActionButton AddNewPostFab, AddNewVideoPost, ViewVideoPostFab;
    RecyclerView postsList, videoPostsList;
    FirebaseAuth mAuth;
    DatabaseReference usersRef, postRef, LikesRef, videopostsRef;
    String currentUserID;
    Toolbar mToolbar;
    DrawerLayout drawerLayout;
    ActionBarDrawerToggle actionBarDrawerToggle;
    Boolean LikeChecker = false;
    LinearLayoutManager linearLayoutManager;
    ImageView no_posts_image, no_posts_video_two;
    TextView tv_one, tv_two, tv_one_two, tv_two_two;
    LinearLayout no_of_posts_layout;
    View videoinflate, imageinflate;


    public PostsFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View postFragmentView = inflater.inflate(R.layout.fragment_posts, container, false);
        setHasOptionsMenu(true);

        mAuth = FirebaseAuth.getInstance();
        currentUserID = mAuth.getCurrentUser().getUid();
       usersRef = FirebaseDatabase.getInstance().getReference().child("Users");
       usersRef.keepSynced(true);
        postRef =  FirebaseDatabase.getInstance().getReference().child("Posts");
        postRef.keepSynced(true);
        LikesRef = FirebaseDatabase.getInstance().getReference().child("Likes");
        LikesRef.keepSynced(true);
        videopostsRef = FirebaseDatabase.getInstance().getReference().child("VideoPosts");
        videopostsRef.keepSynced(true);




        postsList = postFragmentView.findViewById(R.id.all_users_posts_lists);
        postsList.setHasFixedSize(true);
        videoPostsList = postFragmentView.findViewById(R.id.all_users_video_posts_lists);
        videoPostsList.setHasFixedSize(true);
         linearLayoutManager = new LinearLayoutManager(getActivity());
        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);
        postsList.setLayoutManager(linearLayoutManager);
        videoPostsList.setVisibility(View.GONE);
        no_posts_image = postFragmentView.findViewById(R.id.no_posts_image);
        tv_one = postFragmentView.findViewById(R.id.tv_one);
        tv_two = postFragmentView.findViewById(R.id.tv_two);
        no_posts_image.setVisibility(View.GONE);
        tv_one.setVisibility(View.GONE);
        tv_two.setVisibility(View.GONE);
        no_posts_video_two = postFragmentView.findViewById(R.id.no_posts_image_two);
        tv_one_two = postFragmentView.findViewById(R.id.tv_one_two);
        tv_two_two = postFragmentView.findViewById(R.id.tv_two_two);
        no_posts_video_two.setVisibility(View.GONE);
        tv_one_two.setVisibility(View.GONE);
        tv_two_two.setVisibility(View.GONE);

        no_of_posts_layout = postFragmentView.findViewById(R.id.no_of_posts_layout);



        //Delete image posts older than 7 days
        DeleteImagePostsOlderThanFourtyEightHours();
        //Delete video posts older than 7 days
        DeleteVideoPostsOlderThanFourtyEightHours();


        mToolbar = postFragmentView.findViewById(R.id.userhome_navigation_opener_include);
        ((AppCompatActivity)getActivity()).setSupportActionBar(mToolbar);
        ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle("Posts");
        ((AppCompatActivity)getActivity()).getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_menu);
        ((AppCompatActivity)getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        ((AppCompatActivity)getActivity()).getSupportActionBar().setDisplayShowCustomEnabled(true);

        drawerLayout = postFragmentView.findViewById(R.id.all_posts_drawer_layout);
        actionBarDrawerToggle = new ActionBarDrawerToggle(getActivity(), drawerLayout, R.string.drawer_open, R.string.drawer_close);


        postRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.getChildrenCount() != 0){

                    displayAllUsersPosts();

                }else {
                    postsList.setVisibility(View.GONE);

                    no_posts_image.setVisibility(View.VISIBLE);
                    tv_one.setVisibility(View.VISIBLE);
                    tv_two.setVisibility(View.VISIBLE);



                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        AddNewPostFab = postFragmentView.findViewById(R.id.add_post_fab);
        AddNewPostFab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               openAddNewPostActivity();
            }
        });
        AddNewVideoPost = postFragmentView.findViewById(R.id.add_video_post_fab);
        AddNewVideoPost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAddNewVideoPostActivity();
            }
        });

        ViewVideoPostFab = postFragmentView.findViewById(R.id.view_video_post_fab);
        ViewVideoPostFab.setLabelText("View video posts");

        ViewVideoPostFab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                postsList.setVisibility(View.GONE);
                videoPostsList.setVisibility(View.VISIBLE);
                ViewVideoPostFab.setLabelText("View image posts");

                videopostsRef.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if(dataSnapshot.getChildrenCount() != 0){
                            displayAllUsersVideoPosts();
                        }else {
                            no_posts_video_two.setVisibility(View.VISIBLE);
                            tv_one_two.setVisibility(View.VISIBLE);
                            tv_two_two.setVisibility(View.VISIBLE);

                            no_posts_image.setVisibility(View.GONE);
                            tv_one.setVisibility(View.GONE);
                            tv_two.setVisibility(View.GONE);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });



                if(ViewVideoPostFab.getLabelText().equals("View image posts")){
                    ViewVideoPostFab.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            postsList.setVisibility(View.VISIBLE);
                            videoPostsList.setVisibility(View.GONE);
                            ViewVideoPostFab.setLabelText("View video posts");

                            postRef.addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    if(dataSnapshot.getChildrenCount() != 0){

                                        displayAllUsersPosts();

                                    }else {
                                        no_posts_image.setVisibility(View.VISIBLE);
                                        tv_one.setVisibility(View.VISIBLE);
                                        tv_two.setVisibility(View.VISIBLE);

                                        no_posts_video_two.setVisibility(View.GONE);
                                        tv_one_two.setVisibility(View.GONE);
                                        tv_two_two.setVisibility(View.GONE);
                                    }


                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {

                                }
                            });







                            if(ViewVideoPostFab.getLabelText().equals("View video posts")){
                                ViewVideoPostFab.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        postsList.setVisibility(View.GONE);
                                        videoPostsList.setVisibility(View.VISIBLE);
                                        ViewVideoPostFab.setLabelText("View image posts");

                                        videopostsRef.addValueEventListener(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                if(dataSnapshot.getChildrenCount() != 0){
                                                    displayAllUsersVideoPosts();
                                                }else {
                                                    no_posts_video_two.setVisibility(View.VISIBLE);
                                                    tv_one_two.setVisibility(View.VISIBLE);
                                                    tv_two_two.setVisibility(View.VISIBLE);

                                                    no_posts_image.setVisibility(View.GONE);
                                                    tv_one.setVisibility(View.GONE);
                                                    tv_two.setVisibility(View.GONE);
                                                }
                                            }

                                            @Override
                                            public void onCancelled(@NonNull DatabaseError databaseError) {

                                            }
                                        });

                                        if (ViewVideoPostFab.getLabelText().equals("View image posts")) {
                                            ViewVideoPostFab.setOnClickListener(new View.OnClickListener() {
                                                @Override
                                                public void onClick(View v) {
                                                    postsList.setVisibility(View.VISIBLE);
                                                    videoPostsList.setVisibility(View.GONE);
                                                    ViewVideoPostFab.setLabelText("View video posts");

                                                    postRef.addValueEventListener(new ValueEventListener() {
                                                        @Override
                                                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                            if(dataSnapshot.getChildrenCount() != 0){

                                                                displayAllUsersPosts();

                                                            }else {
                                                                no_posts_image.setVisibility(View.VISIBLE);
                                                                tv_one.setVisibility(View.VISIBLE);
                                                                tv_two.setVisibility(View.VISIBLE);

                                                                no_posts_video_two.setVisibility(View.GONE);
                                                                tv_one_two.setVisibility(View.GONE);
                                                                tv_two_two.setVisibility(View.GONE);
                                                            }


                                                        }

                                                        @Override
                                                        public void onCancelled(@NonNull DatabaseError databaseError) {

                                                        }
                                                    });

                                                    if(ViewVideoPostFab.getLabelText().equals("View video posts")){
                                                        ViewVideoPostFab.setOnClickListener(new View.OnClickListener() {
                                                            @Override
                                                            public void onClick(View v) {
                                                                postsList.setVisibility(View.GONE);
                                                                videoPostsList.setVisibility(View.VISIBLE);
                                                                ViewVideoPostFab.setLabelText("View image posts");

                                                                videopostsRef.addValueEventListener(new ValueEventListener() {
                                                                    @Override
                                                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                                        if(dataSnapshot.getChildrenCount() != 0){
                                                                            displayAllUsersVideoPosts();
                                                                        }else {
                                                                            no_posts_video_two.setVisibility(View.VISIBLE);
                                                                            tv_one_two.setVisibility(View.VISIBLE);
                                                                            tv_two_two.setVisibility(View.VISIBLE);

                                                                            no_posts_image.setVisibility(View.GONE);
                                                                            tv_one.setVisibility(View.GONE);
                                                                            tv_two.setVisibility(View.GONE);
                                                                        }
                                                                    }

                                                                    @Override
                                                                    public void onCancelled(@NonNull DatabaseError databaseError) {

                                                                    }
                                                                });


                                                                if (ViewVideoPostFab.getLabelText().equals("View image posts")) {
                                                                    ViewVideoPostFab.setOnClickListener(new View.OnClickListener() {
                                                                        @Override
                                                                        public void onClick(View v) {
                                                                            postsList.setVisibility(View.VISIBLE);
                                                                            videoPostsList.setVisibility(View.GONE);
                                                                            ViewVideoPostFab.setLabelText("View video posts");
                                                                            postRef.addValueEventListener(new ValueEventListener() {
                                                                                @Override
                                                                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                                                    if(dataSnapshot.getChildrenCount() != 0){

                                                                                        displayAllUsersPosts();

                                                                                    }else {
                                                                                        no_posts_image.setVisibility(View.VISIBLE);
                                                                                        tv_one.setVisibility(View.VISIBLE);
                                                                                        tv_two.setVisibility(View.VISIBLE);

                                                                                        no_posts_video_two.setVisibility(View.GONE);
                                                                                        tv_one_two.setVisibility(View.GONE);
                                                                                        tv_two_two.setVisibility(View.GONE);
                                                                                    }


                                                                                }

                                                                                @Override
                                                                                public void onCancelled(@NonNull DatabaseError databaseError) {

                                                                                }
                                                                            });

                                                                        } });
                                                                }

                                                            } });
                                                    }
                                                }
                                            });
                                        }
                                    }

                                });
                            }
                        }

                    });
                }


            }
        });

        // Inflate the layout for this fragment
        return postFragmentView;



    }


    private void  DeleteImagePostsOlderThanFourtyEightHours(){
       //display post for 48 hours
        long cutoff = new Date().getTime() - TimeUnit.MILLISECONDS.convert(2, TimeUnit.DAYS);

        Query oldImagePosts = postRef.orderByChild("timestamp").endAt(cutoff);
        oldImagePosts.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                for(DataSnapshot itemSnapshot: dataSnapshot.getChildren()){

                    //also we delete the image associated with this post from the storage
                    //so we first retrieve the name of the image from the database
                    if(dataSnapshot.exists()){
                        String postimagenameindatabase = itemSnapshot.child("postimagestoragename").getValue().toString();

                        //now, delete the image from the storage
                        StorageReference postimageRef = FirebaseStorage.getInstance().getReference()
                                .child("Post Images").child(postimagenameindatabase);
                        postimageRef.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                // File deleted successfully
                                Log.d("SUCCESS:", "onSuccess: deleted file");
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception exception) {
                                // Uh-oh, an error occurred!
                                Log.d("ERROR:", "onFailure: did not delete file");
                            }
                        });
                    }


                    //remove/delete the file
                    itemSnapshot.getRef().removeValue();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    private void DeleteVideoPostsOlderThanFourtyEightHours() {
        // duration of post is 48 hours.
        long cutoff = new Date().getTime() - TimeUnit.MILLISECONDS.convert(2, TimeUnit.DAYS);

        Query oldVideoPosts = videopostsRef.orderByChild("timestamp").endAt(cutoff);
        oldVideoPosts.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                for(DataSnapshot itemSnapshot: dataSnapshot.getChildren()){

                    final String correspondingpostvideo = itemSnapshot.child("videopoststoragefilename").getValue().toString();

                    //also we delete the video associated with this post from the storage
                    //so we first retrieve the name of the video from the database
                    if(dataSnapshot.exists()){

                        //now, delete the video from the storage
                        StorageReference postvideoRef = FirebaseStorage.getInstance().getReference()
                                .child("Post Videos").child(correspondingpostvideo);
                        postvideoRef.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                // File deleted successfully
                                Log.d("SUCCESS:", "onSuccess: deleted file");
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception exception) {
                                // Uh-oh, an error occurred!
                                Log.d("ERROR:", "onFailure: did not delete file");
                            }
                        });


                    }

                    //remove/delete the file
                    itemSnapshot.getRef().removeValue();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void displayAllUsersVideoPosts() {

        Query SortPostsInDecendingOrder = videopostsRef.orderByChild("counter");


        FirebaseRecyclerAdapter<PostsVideo, VideoPostsViewHolder> firebaseRecyclerAdapter =
                new FirebaseRecyclerAdapter<PostsVideo, VideoPostsViewHolder>
                        (PostsVideo.class,R.layout.all_video_post_layout,VideoPostsViewHolder.class, SortPostsInDecendingOrder) {
                    @Override
                    protected void populateViewHolder(final VideoPostsViewHolder viewHolder, PostsVideo model, int position) {

                        final String PostKey = getRef(position).getKey();


                        viewHolder.setFullname(model.getFullname());
                        viewHolder.setDate(model.getDate());
                        viewHolder.setDescription(model.getDescription());
                        viewHolder.setTime(model.getTime());
                        viewHolder.setTitle(model.getTitle());
                        viewHolder.setPostvideo(getActivity(),model.getPostvideo());
                        viewHolder.setProfileimage(getActivity(), model.getProfileimage());

                        viewHolder.setLikeButtonStatus(PostKey);
                        viewHolder.setNoOfComments(PostKey);

                        viewHolder.mView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Intent postClickintent = new Intent(getActivity(), PostVideoDetails.class);
                                postClickintent.putExtra("PostKey", PostKey);
                                Pair[] pairs = new Pair[2];
                                pairs[0] = new Pair<View, String>(viewHolder.videoView, "sharedVideoView");
                                pairs[1] = new Pair<View, String>(viewHolder.userimage, "sharedProfileImage");
                                ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(getActivity(), pairs);
                                startActivity(postClickintent, options.toBundle());
                            }
                        });


                        viewHolder.download_a_post.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {

                                videopostsRef.child(PostKey).addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        if(dataSnapshot.exists()){
                                            String postImage = dataSnapshot.child("postvideo").getValue().toString();

                                            String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
                                                    .format(System.currentTimeMillis());

                                            File root = Environment.getExternalStorageDirectory();
                                            root.mkdirs();
                                            String path = root.toString();

                                            downloadPostImage(getActivity(), timestamp
                                                    , ".mp4", path + "/NAMSSN MESSENGER" + "/Post Videos" ,
                                                    postImage);
                                        }

                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {

                                    }
                                });

                            }
                        });

                        viewHolder.comment_on_a_post.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Intent postcomment = new Intent(getActivity(), PostVideoDetails.class);
                                postcomment.putExtra("PostKey", PostKey);
                                Pair[] pairs = new Pair[2];
                                pairs[0] = new Pair<View, String>(viewHolder.videoView, "sharedVideoView");
                                pairs[1] = new Pair<View, String>(viewHolder.userimage, "sharedProfileImage");
                                ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(getActivity(), pairs);
                                startActivity(postcomment, options.toBundle());
                            }
                        });

                        viewHolder.like_a_post_button.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {

                                LikeChecker = true;

                                LikesRef.addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                                        if(LikeChecker.equals(true)){
                                            if(dataSnapshot.child(PostKey).hasChild(currentUserID)){
                                                LikesRef.child(PostKey).child(currentUserID).removeValue();
                                                LikeChecker = false;
                                            }
                                            else{

                                                LikesRef.child(PostKey).child(currentUserID).setValue(true);
                                                LikeChecker = false;
                                            }
                                        }
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {

                                    }
                                });
                            }
                        });


                    }
                };

        videoPostsList.setAdapter(firebaseRecyclerAdapter);
    }

    public static class VideoPostsViewHolder extends RecyclerView.ViewHolder{
        View mView;

        ImageButton like_a_post_button, comment_on_a_post, download_a_post;
        TextView no_of_post_likes, no_of_post_comments;


        int countLikes, commentsCount;
        String currentuser_id;
        DatabaseReference LikesRef;
         MediaController mediaController;


        final VideoView videoView;
        final CircleImageView userimage;




        public VideoPostsViewHolder(@NonNull View itemView) {
            super(itemView);
            mView = itemView;


            userimage = mView.findViewById(R.id.user_post_profile_image);
            videoView = mView.findViewById(R.id.post_video);
            like_a_post_button = mView.findViewById(R.id.like_a_post);
            comment_on_a_post = mView.findViewById(R.id.comment_on_post);
            download_a_post = mView.findViewById(R.id.download_post_image);


            no_of_post_likes = mView.findViewById(R.id.number_of_likes_textView);
            no_of_post_comments = mView.findViewById(R.id.no_of_comments_textView);

            LikesRef = FirebaseDatabase.getInstance().getReference().child("Likes");
            currentuser_id = FirebaseAuth.getInstance().getCurrentUser().getUid();
        }

        public void setNoOfComments(final String PostKey) {

            DatabaseReference CommentsPostsRef;
            CommentsPostsRef = FirebaseDatabase.getInstance().getReference().child("VideoPosts").child(PostKey).child("Comments");

            CommentsPostsRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    dataSnapshot.getKey();
                    commentsCount  = (int)dataSnapshot.getChildrenCount();
                    no_of_post_comments.setText(commentsCount + " Comments");

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {


                }
            });

        }

        public void setLikeButtonStatus(final String PostKey){
            LikesRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    if(dataSnapshot.child(PostKey).hasChild(currentuser_id)){
                        countLikes = (int) dataSnapshot.child(PostKey).getChildrenCount();
                        like_a_post_button.setImageResource(R.drawable.ic_liked);
                        no_of_post_likes.setText((Integer.toString(countLikes)) + (" Likes"));
                    }
                    else {
                        countLikes = (int) dataSnapshot.child(PostKey).getChildrenCount();
                        like_a_post_button.setImageResource(R.drawable.ic_like);
                        no_of_post_likes.setText((Integer.toString(countLikes)) + (" Likes"));
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }

        public void setFullname(String fullname){
            TextView username = mView.findViewById(R.id.post_username);
            username.setText(fullname);
        }
        public void setPostvideo(final Context ctx, final String postvideo){

            LinearLayout controls_layout;
            controls_layout = mView.findViewById(R.id.controls_layout);
            controls_layout.setVisibility(View.GONE);


            final ProgressBar loading_video_progress_bar = mView.findViewById(R.id.loading_video_progress_bar);

            videoView.setVideoURI(Uri.parse(postvideo));
            videoView.requestFocus();
            videoView.setBackgroundColor(ctx.getResources().getColor(R.color.default_video_post_bg));





            videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {



                @Override
                public void onPrepared(MediaPlayer mp) {

                    mp.setOnVideoSizeChangedListener(new MediaPlayer.OnVideoSizeChangedListener() {
                        @Override
                        public void onVideoSizeChanged(MediaPlayer mp, int width, int height) {
                            mediaController = new MediaController(ctx);
                            videoView.setMediaController(mediaController);
                            mediaController.setAnchorView(videoView);
                        }
                    });


                    mp.setOnInfoListener(new MediaPlayer.OnInfoListener() {
                                @Override
                                public boolean onInfo(MediaPlayer mp, int what, int extra) {
                                    if(what == mp.MEDIA_INFO_BUFFERING_END){
                                        loading_video_progress_bar.setVisibility(View.INVISIBLE);
                                        return true;
                                    }
                                    else if(what == mp.MEDIA_INFO_BUFFERING_START){
                                        loading_video_progress_bar.setVisibility(View.VISIBLE);
                                    }
                                    return false;
                                }
                            });

                    videoView.start();
                    videoView.setBackgroundColor(0);
                    loading_video_progress_bar.setVisibility(View.INVISIBLE);


                      videoView.seekTo(videoView.getCurrentPosition());
                    if(videoView.getCurrentPosition() != 0){
                        videoView.start();

                    }else {
                        videoView.pause();
                    }


                }
            });




        }
        public void setProfileimage(final Context ctx, final String profileimage){

            Picasso.with(ctx).load(profileimage).networkPolicy(NetworkPolicy.OFFLINE)
                    .into(userimage, new Callback() {
                        @Override
                        public void onSuccess() {

                        }

                        @Override
                        public void onError() {

                            Picasso.with(ctx).load(profileimage).into(userimage);
                        }
                    });
        }
        public void setTime(String time){
            TextView PostTime = mView.findViewById(R.id.post_time);
            PostTime.setText(time);
        }
        public void setDate(String date){
            TextView PostDate = mView.findViewById(R.id.post_date);
            PostDate.setText(date + " at ");
        }
        public void setTitle(String title){
            TextView PostTitle = mView.findViewById(R.id.post_title);
            PostTitle.setText(title);
        }
        public void setDescription(String description){
            TextView PostDescription = mView.findViewById(R.id.post_description);
            PostDescription.setText(description);
        }



    }


    private void openAddNewVideoPostActivity() {
        //open the add new video post activity
        Intent addVideoPostIntent = new Intent(getContext(),AddNewVideoPost.class);
        ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(getActivity());
        startActivity(addVideoPostIntent, options.toBundle());
    }


    public void firebasePostsSearch(String searchText){
        Query firebaseSearchQuery = postRef.orderByChild("posttitletolowercase").startAt(searchText).endAt(searchText + "\uf0ff");

        final FirebaseRecyclerAdapter<Posts, PostsViewHolder> firebaseRecyclerAdapter =
                new FirebaseRecyclerAdapter<Posts, PostsViewHolder>
                        (Posts.class,R.layout.all_posts_layout,PostsViewHolder.class, firebaseSearchQuery) {
                    @Override
                    protected void populateViewHolder(final PostsViewHolder viewHolder, Posts model, int position) {

                        final String PostKey = getRef(position).getKey();

                        viewHolder.setFullname(model.getFullname());
                        viewHolder.setDate(model.getDate());
                        viewHolder.setDescription(model.getDescription());
                        viewHolder.setTime(model.getTime());
                        viewHolder.setTitle(model.getTitle());
                        viewHolder.setPostimage(getActivity(),model.getPostimage());
                        viewHolder.setProfileimage(getActivity(), model.getProfileimage());

                        viewHolder.setLikeButtonStatus(PostKey);
                        viewHolder.setNoOfComments(PostKey);

                        viewHolder.mView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Intent postClickintent = new Intent(getActivity(), PostDetail.class);
                                postClickintent.putExtra("PostKey", PostKey);
                                Pair[] pairs = new Pair[2];
                                pairs[0] = new Pair<View, String>(viewHolder.postImage, "sharedPostImage");
                                pairs[1] = new Pair<View, String>(viewHolder.userimage, "sharedProfileImage");
                                ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(getActivity(), pairs);
                                startActivity(postClickintent, options.toBundle());
                            }
                        });



                        final DatabaseReference postImageDownload = FirebaseDatabase.getInstance().getReference().child("Posts");
                        viewHolder.download_a_post.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {

                                postImageDownload.child(PostKey).addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        if(dataSnapshot.exists()){
                                            String postImage = dataSnapshot.child("postimage").getValue().toString();

                                            String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
                                                    .format(System.currentTimeMillis());

                                            File root = Environment.getExternalStorageDirectory();
                                            root.mkdirs();
                                            String path = root.toString();

                                            downloadPostImage(getActivity(), timestamp
                                                    , ".jpg", path + "/NAMSSN MESSENGER" + "/Post Images" ,
                                                    postImage);
                                        }

                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {

                                    }
                                });

                            }
                        });

                        viewHolder.comment_on_a_post.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Intent postcomment = new Intent(getActivity(), PostDetail.class);
                                postcomment.putExtra("PostKey", PostKey);
                                Pair[] pairs = new Pair[2];
                                pairs[0] = new Pair<View, String>(viewHolder.postImage, "sharedPostImage");
                                pairs[1] = new Pair<View, String>(viewHolder.userimage, "sharedProfileImage");
                                ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(getActivity(), pairs);
                                startActivity(postcomment, options.toBundle());
                            }
                        });

                        viewHolder.like_a_post_button.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {

                                LikeChecker = true;

                                LikesRef.addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                                        if(LikeChecker.equals(true)){
                                            if(dataSnapshot.child(PostKey).hasChild(currentUserID)){
                                                LikesRef.child(PostKey).child(currentUserID).removeValue();
                                                LikeChecker = false;
                                            }
                                            else{

                                                LikesRef.child(PostKey).child(currentUserID).setValue(true);
                                                LikeChecker = false;
                                            }
                                        }
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {

                                    }
                                });
                            }
                        });


                    }
                };

        postsList.setAdapter(firebaseRecyclerAdapter);


        firebaseSearchQuery.addValueEventListener(new ValueEventListener() {
           @Override
           public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
               imageinflate = View.inflate(getActivity(), R.layout.no_image_posts_query_result, no_of_posts_layout);

               if(dataSnapshot.exists()){
                   postsList.setVisibility(View.VISIBLE);
                   postsList.setAdapter(firebaseRecyclerAdapter);


                   no_posts_video_two.setVisibility(View.GONE);
                   tv_two_two.setVisibility(View.GONE);
                   tv_one_two.setVisibility(View.GONE);

                   no_posts_image.setVisibility(View.GONE);
                   tv_one.setVisibility(View.GONE);
                   tv_two.setVisibility(View.GONE);

               }else {
                   postsList.setVisibility(View.GONE);

                   imageinflate.setVisibility(View.VISIBLE);

                   no_posts_video_two.setVisibility(View.GONE);
                   tv_two_two.setVisibility(View.GONE);
                   tv_one_two.setVisibility(View.GONE);

                   no_posts_image.setVisibility(View.GONE);
                   tv_one.setVisibility(View.GONE);
                   tv_two.setVisibility(View.GONE);

               }
           }

           @Override
           public void onCancelled(@NonNull DatabaseError databaseError) {

           }
       });


    }


    public void firebaseVideoPostsSearch(String vsearchText){
        Query firebaseVideoSearchQuery = videopostsRef.orderByChild("title").startAt(vsearchText).endAt(vsearchText + "\uf0ff");


        final FirebaseRecyclerAdapter<PostsVideo, VideoPostsViewHolder> firebaseRecyclerAdapter =
                new FirebaseRecyclerAdapter<PostsVideo, VideoPostsViewHolder>
                        (PostsVideo.class,R.layout.all_video_post_layout,VideoPostsViewHolder.class, firebaseVideoSearchQuery) {
                    @Override
                    protected void populateViewHolder(final VideoPostsViewHolder viewHolder, PostsVideo model, int position) {

                        final String PostKey = getRef(position).getKey();


                        viewHolder.setFullname(model.getFullname());
                        viewHolder.setDate(model.getDate());
                        viewHolder.setDescription(model.getDescription());
                        viewHolder.setTime(model.getTime());
                        viewHolder.setTitle(model.getTitle());
                        viewHolder.setPostvideo(getActivity(),model.getPostvideo());
                        viewHolder.setProfileimage(getActivity(), model.getProfileimage());

                        viewHolder.setLikeButtonStatus(PostKey);
                        viewHolder.setNoOfComments(PostKey);

                        viewHolder.mView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Intent postClickintent = new Intent(getActivity(), PostVideoDetails.class);
                                postClickintent.putExtra("PostKey", PostKey);
                                Pair[] pairs = new Pair[2];
                                pairs[0] = new Pair<View, String>(viewHolder.videoView, "sharedVideoView");
                                pairs[1] = new Pair<View, String>(viewHolder.userimage, "sharedProfileImage");
                                ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(getActivity(), pairs);
                                startActivity(postClickintent, options.toBundle());
                            }
                        });


                        viewHolder.download_a_post.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {

                                videopostsRef.child(PostKey).addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        if(dataSnapshot.exists()){
                                            String postImage = dataSnapshot.child("postvideo").getValue().toString();

                                            String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
                                                    .format(System.currentTimeMillis());

                                            File root = Environment.getExternalStorageDirectory();
                                            root.mkdirs();
                                            String path = root.toString();

                                            downloadPostImage(getActivity(), timestamp
                                                    , ".mp4", path + "/NAMSSN MESSENGER" + "/Post Videos" ,
                                                    postImage);
                                        }

                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {

                                    }
                                });

                            }
                        });

                        viewHolder.comment_on_a_post.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Intent postcomment = new Intent(getActivity(), PostVideoDetails.class);
                                postcomment.putExtra("PostKey", PostKey);
                                Pair[] pairs = new Pair[2];
                                pairs[0] = new Pair<View, String>(viewHolder.videoView, "sharedVideoView");
                                pairs[1] = new Pair<View, String>(viewHolder.userimage, "sharedProfileImage");
                                ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(getActivity(), pairs);
                                startActivity(postcomment, options.toBundle());
                            }
                        });

                        viewHolder.like_a_post_button.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {

                                LikeChecker = true;

                                LikesRef.addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                                        if(LikeChecker.equals(true)){
                                            if(dataSnapshot.child(PostKey).hasChild(currentUserID)){
                                                LikesRef.child(PostKey).child(currentUserID).removeValue();
                                                LikeChecker = false;
                                            }
                                            else{

                                                LikesRef.child(PostKey).child(currentUserID).setValue(true);
                                                LikeChecker = false;
                                            }
                                        }
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {

                                    }
                                });
                            }
                        });


                    }
                };

        videoPostsList.setAdapter(firebaseRecyclerAdapter);

        firebaseVideoSearchQuery.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                videoinflate = View.inflate(getActivity(), R.layout.no_video_posts_query, no_of_posts_layout);
                if(dataSnapshot.exists()){
                    videoPostsList.setVisibility(View.VISIBLE);
                    no_posts_video_two.setVisibility(View.GONE);
                    tv_one_two.setVisibility(View.GONE);
                    videoPostsList.setAdapter(firebaseRecyclerAdapter);

                    no_posts_video_two.setVisibility(View.GONE);
                    tv_two_two.setVisibility(View.GONE);
                    tv_one_two.setVisibility(View.GONE);

                    no_posts_image.setVisibility(View.GONE);
                    tv_one.setVisibility(View.GONE);
                    tv_two.setVisibility(View.GONE);

                }else {
                    videoPostsList.setVisibility(View.GONE);
                    videoinflate.setVisibility(View.VISIBLE);

                    no_posts_video_two.setVisibility(View.GONE);
                    tv_two_two.setVisibility(View.GONE);
                    tv_one_two.setVisibility(View.GONE);

                    no_posts_image.setVisibility(View.GONE);
                    tv_one.setVisibility(View.GONE);
                    tv_two.setVisibility(View.GONE);

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.search_view_menu, menu);

        MenuItem item = menu.findItem(R.id.action_search);

        SearchView searchView = (SearchView)MenuItemCompat.getActionView(item);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                if(ViewVideoPostFab.getLabelText().equals("View video posts")){
                    firebasePostsSearch(query);
                }else {
                    firebaseVideoPostsSearch(query);
                }

                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if(ViewVideoPostFab.getLabelText().equals("View video posts")){
                    firebasePostsSearch(newText);
                }else {
                    firebaseVideoPostsSearch(newText);
                }
                return false;
            }
        });
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(actionBarDrawerToggle.onOptionsItemSelected(item)){
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    public void displayAllUsersPosts() {

        Query SortPostsInDecendingOrder = postRef.orderByChild("counter");


        FirebaseRecyclerAdapter<Posts, PostsViewHolder> firebaseRecyclerAdapter =
                new FirebaseRecyclerAdapter<Posts, PostsViewHolder>
                        (Posts.class,R.layout.all_posts_layout,PostsViewHolder.class, SortPostsInDecendingOrder) {
            @Override
            protected void populateViewHolder(final PostsViewHolder viewHolder, Posts model, int position) {

                final String PostKey = getRef(position).getKey();


                viewHolder.setFullname(model.getFullname());
                viewHolder.setDate(model.getDate());
                viewHolder.setDescription(model.getDescription());
                viewHolder.setTime(model.getTime());
                viewHolder.setTitle(model.getTitle());
                viewHolder.setPostimage(getActivity(),model.getPostimage());
                viewHolder.setProfileimage(getActivity(), model.getProfileimage());

                viewHolder.setLikeButtonStatus(PostKey);
                viewHolder.setNoOfComments(PostKey);

                viewHolder.mView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent postClickintent = new Intent(getActivity(), PostDetail.class);
                        postClickintent.putExtra("PostKey", PostKey);
                        Pair[] pairs = new Pair[2];
                        pairs[0] = new Pair<View, String>(viewHolder.postImage, "sharedPostImage");
                        pairs[1] = new Pair<View, String>(viewHolder.userimage, "sharedProfileImage");
                        ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(getActivity(), pairs);
                        startActivity(postClickintent, options.toBundle());
                    }
                });



                final DatabaseReference postImageDownload = FirebaseDatabase.getInstance().getReference().child("Posts");
                viewHolder.download_a_post.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        postImageDownload.child(PostKey).addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                if(dataSnapshot.exists()){
                                    String postImage = dataSnapshot.child("postimage").getValue().toString();

                                    String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
                                            .format(System.currentTimeMillis());

                                    File root = Environment.getExternalStorageDirectory();
                                    root.mkdirs();
                                    String path = root.toString();

                                    downloadPostImage(getActivity(), timestamp
                                            , ".jpg", path + "/NAMSSN MESSENGER" + "/Post Images" ,
                                            postImage);
                                }

                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });

                    }
                });

                viewHolder.comment_on_a_post.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent postcomment = new Intent(getActivity(), PostDetail.class);
                        postcomment.putExtra("PostKey", PostKey);
                        Pair[] pairs = new Pair[2];
                        pairs[0] = new Pair<View, String>(viewHolder.postImage, "sharedPostImage");
                        pairs[1] = new Pair<View, String>(viewHolder.userimage, "sharedProfileImage");
                        ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(getActivity(),pairs);
                        startActivity(postcomment, options.toBundle());
                    }
                });

                viewHolder.like_a_post_button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        LikeChecker = true;

                        LikesRef.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                               if(LikeChecker.equals(true)){
                                   if(dataSnapshot.child(PostKey).hasChild(currentUserID)){
                                       LikesRef.child(PostKey).child(currentUserID).removeValue();
                                       LikeChecker = false;
                                   }
                                   else{

                                       LikesRef.child(PostKey).child(currentUserID).setValue(true);
                                       LikeChecker = false;
                                   }
                               }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                    }
                });


            }
        };

        postsList.setAdapter(firebaseRecyclerAdapter);

    }

    public static class PostsViewHolder extends RecyclerView.ViewHolder{
        View mView;

        ImageButton like_a_post_button, comment_on_a_post, download_a_post;
        TextView no_of_post_likes, no_of_post_comments;

        int countLikes, commentsCount;
        String currentuser_id;
        DatabaseReference LikesRef;
        final CircleImageView userimage;
        final ImageView postImage;


        public PostsViewHolder(@NonNull View itemView) {
            super(itemView);
            mView = itemView;


            postImage = mView.findViewById(R.id.post_image);
            userimage = mView.findViewById(R.id.user_post_profile_image);
             like_a_post_button = mView.findViewById(R.id.like_a_post);
             comment_on_a_post = mView.findViewById(R.id.comment_on_post);
             download_a_post = mView.findViewById(R.id.download_post_image);

            no_of_post_likes = mView.findViewById(R.id.number_of_likes_textView);
            no_of_post_comments = mView.findViewById(R.id.no_of_comments_textView);

            LikesRef = FirebaseDatabase.getInstance().getReference().child("Likes");
            currentuser_id = FirebaseAuth.getInstance().getCurrentUser().getUid();
        }

        public void setNoOfComments(final String PostKey) {

            DatabaseReference CommentsPostsRef;
            CommentsPostsRef = FirebaseDatabase.getInstance().getReference().child("Posts").child(PostKey).child("Comments");

            CommentsPostsRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    dataSnapshot.getKey();
                     commentsCount  = (int)dataSnapshot.getChildrenCount();
                     no_of_post_comments.setText(commentsCount + " Comments");

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {


                }
            });

        }

        public void setLikeButtonStatus(final String PostKey){
            LikesRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    if(dataSnapshot.child(PostKey).hasChild(currentuser_id)){
                        countLikes = (int) dataSnapshot.child(PostKey).getChildrenCount();
                        like_a_post_button.setImageResource(R.drawable.ic_liked);
                        no_of_post_likes.setText((Integer.toString(countLikes)) + (" Likes"));
                    }
                    else {
                        countLikes = (int) dataSnapshot.child(PostKey).getChildrenCount();
                        like_a_post_button.setImageResource(R.drawable.ic_like);
                        no_of_post_likes.setText((Integer.toString(countLikes)) + (" Likes"));
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }

        public void setFullname(String fullname){
            TextView username = mView.findViewById(R.id.post_username);
            username.setText(fullname);
        }

        public void setProfileimage(final Context ctx, final String profileimage){

            Picasso.with(ctx).load(profileimage).networkPolicy(NetworkPolicy.OFFLINE)
                    .into(userimage, new Callback() {
                        @Override
                        public void onSuccess() {

                        }

                        @Override
                        public void onError() {

                            Picasso.with(ctx).load(profileimage).into(userimage);
                        }
                    });
        }

        public void setTime(String time){
            TextView PostTime = mView.findViewById(R.id.post_time);
            PostTime.setText(time);
        }

        public void setDate(String date){
            TextView PostDate = mView.findViewById(R.id.post_date);
            PostDate.setText(date + " at ");
        }
        public void setTitle(String title){
            TextView PostTitle = mView.findViewById(R.id.post_title);
            PostTitle.setText(title);
        }
        public void setDescription(String description){
            TextView PostDescription = mView.findViewById(R.id.post_description);
            PostDescription.setText(description);
        }
        public void setPostimage(final Context ctx, final String postimage){

            Picasso.with(ctx).load(postimage).networkPolicy(NetworkPolicy.OFFLINE)
                    .into(postImage, new Callback() {
                        @Override
                        public void onSuccess() {

                        }

                        @Override
                        public void onError() {

                            Picasso.with(ctx).load(postimage).into(postImage);
                        }
                    });
        }


    }


    public void downloadPostImage(Context context, String FileName, String FileExtension, String
                                  DestinationDirectory, String uri){
        DownloadManager downloadManager = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
        Uri uri1 = Uri.parse(uri);
        DownloadManager.Request request = new DownloadManager.Request(uri1);
        request.setTitle("NAMSSN MESSENGER (" + FileName + FileExtension +")");
        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
        request.setDestinationInExternalFilesDir(context, DestinationDirectory, FileName + FileExtension);
        downloadManager.enqueue(request);
    }

    public void openAddNewPostActivity(){
        //open the add new post activity
        Intent addPostIntent = new Intent(getContext(),AddNewPost.class);
        ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(getActivity());
        startActivity(addPostIntent, options.toBundle());
    }

}
