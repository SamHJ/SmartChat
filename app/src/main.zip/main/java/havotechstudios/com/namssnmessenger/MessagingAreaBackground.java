package havotechstudios.com.namssnmessenger;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;

public class MessagingAreaBackground extends AppCompatActivity {

    RelativeLayout bg_settings_layout;
    RadioGroup bg_radio_group;
    RelativeLayout messaging_area_layout;
    Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_messaging_area_background);

        SharedPreferences preferences = getSharedPreferences("MESSAGING_AREA_BG", Context.MODE_PRIVATE);
        final SharedPreferences.Editor editor = preferences.edit();

        bg_settings_layout = findViewById(R.id.bg_settings_layout);
        bg_radio_group =findViewById(R.id.bg_radio_group);
        toolbar = findViewById(R.id.messages_bg_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle("Change Chat Background");

        if(preferences.contains(("backgroundId"))){
            bg_settings_layout.setBackgroundResource(preferences.getInt("backgroundId", 0));

        }




        bg_radio_group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                int BackgroundCode = 0;

                switch (checkedId) {
                    case R.id.default_radio_btn:
                        BackgroundCode = R.mipmap.default_cbg;
                        break;
                    case R.id.bubble_radio_btn:
                        BackgroundCode = R.mipmap.bubble_purple;
                        break;
                    case R.id.goldie_radio_btn:
                        BackgroundCode = R.mipmap.goldie;
                        break;
                    case R.id.clown_radio_btn:
                        BackgroundCode = R.mipmap.clown;
                        break;
                    case R.id.headshot_radio_btn:
                        BackgroundCode = R.mipmap.headshot;
                        break;
                    case R.id.road_radio_btn:
                        BackgroundCode = R.mipmap.road;
                        break;
                    case R.id.robot_radio_btn:
                        BackgroundCode = R.mipmap.robot;
                        break;
                    case R.id.selfie_radio_btn:
                        BackgroundCode = R.mipmap.selfie;
                        break;
                }

                bg_settings_layout.setBackgroundResource(BackgroundCode);
                editor.putInt("backgroundId", BackgroundCode);
                editor.apply();

            }
        });

    }
}
