package havotechstudios.com.namssnmessenger;

import android.annotation.SuppressLint;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.view.menu.MenuBuilder;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Callback;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Locale;

public class FullPersonProfileImage extends AppCompatActivity {

    Toolbar toolbar;
    ImageView full_profile_image;
    FloatingActionButton share_fab;
    DatabaseReference profileUserRef;
    String currentUserID, receiverUserID;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_full_person_profile_image);

        receiverUserID = getIntent().getExtras().get("PostKey").toString();

        toolbar = findViewById(R.id.navigation_opener_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        Window window = this.getWindow();
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(FullPersonProfileImage.this.getResources().getColor(R.color.intro_title_color));

        profileUserRef = FirebaseDatabase.getInstance().getReference().child("Users").child(receiverUserID);
        profileUserRef.keepSynced(true);

        full_profile_image = findViewById(R.id.full_profile_image);
        share_fab = findViewById(R.id.share_fab);



        profileUserRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){
                    final String profile_image = dataSnapshot.child("profileimage").getValue().toString();
                    String user_fullname = dataSnapshot.child("fullname").getValue().toString();
                    getSupportActionBar().setTitle(user_fullname);

                    Picasso.with(FullPersonProfileImage.this).load(profile_image).networkPolicy(NetworkPolicy.OFFLINE)
                            .placeholder(R.drawable.easy_to_use).into(full_profile_image, new
                            Callback() {
                                @Override
                                public void onSuccess() {

                                }

                                @Override
                                public void onError() {

                                    Picasso.with(FullPersonProfileImage.this).load(profile_image).placeholder(R.drawable.easy_to_use).into(full_profile_image);
                                }
                            });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });



                profileUserRef.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull final DataSnapshot dataSnapshot) {
                        if(dataSnapshot.exists()){
                           share_fab.setOnClickListener(new View.OnClickListener() {
                               @Override
                               public void onClick(View v) {
                                   String profile_image = dataSnapshot.child("profileimage").getValue().toString();
                                   String user_fullname = dataSnapshot.child("fullname").getValue().toString();
                                   Uri uri = Uri.parse(profile_image);
                                   Intent shareIntent = new Intent(Intent.ACTION_SEND);
                                   shareIntent.setType("image/*");
                                   shareIntent.putExtra(Intent.EXTRA_STREAM, uri);
                                   startActivity(Intent.createChooser(shareIntent, "Share " + user_fullname + "'s profile image via"));

                               }
                           });
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

    }


    @SuppressLint("RestrictedApi")
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.full_image_menu, menu);
        if(menu instanceof MenuBuilder){
            MenuBuilder menuBuilder = (MenuBuilder) menu;
            menuBuilder.setOptionalIconsVisible(true);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.full_image_menu_id:
                DownloadImageToPhone();
                return true;
            case android.R.id.home:
                finish();
            default:
                return super.onOptionsItemSelected(item);
        }
    }



    public void DownloadImageToPhone(){

        profileUserRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){
                    final String profile_image = dataSnapshot.child("profileimage").getValue().toString();
                    String user_fullname = dataSnapshot.child("fullname").getValue().toString();
                    String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
                            .format(System.currentTimeMillis());

                    File root = Environment.getExternalStorageDirectory();
                    root.mkdirs();
                    String path = root.toString();
                    String FileName = user_fullname + timestamp;
                    String FileExtension = ".jpg";
                    String DestinationDirectory = path + "/NAMSSN MESSENGER" + "/Profile Images";

                    DownloadManager downloadManager = (DownloadManager) FullPersonProfileImage.this.getSystemService(Context.DOWNLOAD_SERVICE);
                    Uri uri1 = Uri.parse(profile_image);
                    DownloadManager.Request request = new DownloadManager.Request(uri1);
                    request.setTitle("NAMSSN MESSENGER (" + FileName + FileExtension +")");
                    request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    request.setDestinationInExternalFilesDir(FullPersonProfileImage.this, DestinationDirectory, FileName + FileExtension);
                    downloadManager.enqueue(request);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }


}
