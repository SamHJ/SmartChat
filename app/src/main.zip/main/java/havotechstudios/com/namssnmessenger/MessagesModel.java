package havotechstudios.com.namssnmessenger;

public class MessagesModel {

    public String message, time, date, type, from, to, messageID, name, extension;
    private boolean isseen;

    public MessagesModel() {

    }


    public MessagesModel(String message, String time, String date, String type, String from, String to, String messageID, String name, String extension, boolean isseen) {
        this.message = message;
        this.time = time;
        this.date = date;
        this.type = type;
        this.from = from;
        this.isseen = isseen;
        this.to = to;
        this.messageID = messageID;
        this.name = name;
        this.extension = extension;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isIsseen() {
        return isseen;
    }

    public void setIsseen(boolean isseen) {
        this.isseen = isseen;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }

    public String getMessageID() {
        return messageID;
    }

    public void setMessageID(String messageID) {
        this.messageID = messageID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getExtension() {
        return extension;
    }

    public void setExtension(String extension) {
        this.extension = extension;
    }
}