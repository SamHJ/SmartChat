package havotechstudios.com.namssnmessenger;

import android.app.ActivityOptions;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.annotation.NonNull;
import android.support.design.internal.BottomNavigationItemView;
import android.support.design.internal.BottomNavigationMenuView;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.support.v7.widget.Toolbar;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;


import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.squareup.picasso.Callback;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;
import es.dmoral.toasty.Toasty;

public class UserHome extends AppCompatActivity {

    private BottomNavigationView mMainNav;
     FrameLayout mMainFrame;
     FeedsFragment feedsFragment;
     PostsFragment postsFragment;
     MessagesFragment messagesFragment;
     FriendsFragment friendsFragment;
     RequestsFragment requestsFragment;
     ActionBarDrawerToggle actionBarDrawerToggle;
     NavigationView navigationView;
     DrawerLayout drawerLayout;
     Toolbar mToolbar;
     FirebaseAuth mAuth;
     DatabaseReference UserRef, PostsRef, VideoPostsRef;
     CircleImageView NavDrawerProfileImage;
     TextView NavDrawerProfileUsername;
     String currentUserID;
     Dialog profilePopupDialog;

    TextView textClosDialog;
    Button btnViewProfile;
    CircleImageView PopupProfileImage;
    TextView popUpDialogFullName, no_of_posts;
    TextView PopUpDialogschool, popUpdialog_status, PopUpDialogInterestedIn;
    int countPosts = 0, countVideoPosts;
    LinearLayout no_of_posts_layout;
     TextView no_of_unread_messages;
     FirebaseFirestore firebaseFirestore;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_home);

        mAuth = FirebaseAuth.getInstance();
        currentUserID = mAuth.getCurrentUser().getUid();
        UserRef = FirebaseDatabase.getInstance().getReference().child("Users");
        UserRef.keepSynced(true);
        PostsRef = FirebaseDatabase.getInstance().getReference().child("Posts");
        PostsRef.keepSynced(true);
        VideoPostsRef = FirebaseDatabase.getInstance().getReference().child("VideoPosts");
        VideoPostsRef.keepSynced(true);

        mToolbar = findViewById(R.id.userhome_navigation_opener_include);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setTitle("Namssn Messenger");

        mMainFrame = findViewById(R.id.main_frame);
        mMainNav = findViewById(R.id.main_nav);
        firebaseFirestore = FirebaseFirestore.getInstance();


        BottomNavigationMenuView bottomNavigationMenuView
                = (BottomNavigationMenuView) mMainNav.getChildAt(0);
        View view = bottomNavigationMenuView.getChildAt(2);
        BottomNavigationItemView itemView = (BottomNavigationItemView) view;
        final View badge = LayoutInflater.from(getApplicationContext())
                .inflate(R.layout.notification_bagde_layout, itemView, true);
        no_of_unread_messages = badge.findViewById(R.id.notifications_badge);



        checkformessages();



        drawerLayout = findViewById(R.id.drawer_layout);
        actionBarDrawerToggle = new ActionBarDrawerToggle(UserHome.this, drawerLayout, R.string.drawer_open, R.string.drawer_close);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
        profilePopupDialog = new Dialog(this);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        profilePopupDialog.setContentView(R.layout.custom_profile_dialog);
        textClosDialog = profilePopupDialog.findViewById(R.id.text_close_dialog);
        btnViewProfile = profilePopupDialog.findViewById(R.id.btn_view_profile);
        PopupProfileImage = profilePopupDialog.findViewById(R.id.userhome_profile_dialog_image);
        popUpDialogFullName = profilePopupDialog.findViewById(R.id.popup_dialog_fullname);
        PopUpDialogschool = profilePopupDialog.findViewById(R.id.popup_dialog_school);
        popUpdialog_status = profilePopupDialog.findViewById(R.id.popup_dialog_status);
        PopUpDialogInterestedIn = profilePopupDialog.findViewById(R.id.popup_dialog_interestedin);
        no_of_posts = profilePopupDialog.findViewById(R.id.no_of_posts);
        no_of_posts_layout = profilePopupDialog.findViewById(R.id.no_of_posts_layout);

        no_of_posts_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent noOfPostsIntent = new Intent(UserHome.this, AllMyPosts.class);
                ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(UserHome.this);
                startActivity(noOfPostsIntent, options.toBundle());
            }
        });

        btnViewProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent dialog_to_profile = new Intent(UserHome.this, Profile.class);
                final  String PostToProfileKey = "userhomeprofiledialogtoprofileactivity";
                dialog_to_profile.putExtra("PostToProfile", PostToProfileKey);
                ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(UserHome.this);
                startActivity(dialog_to_profile, options.toBundle());
            }
        });






        navigationView = findViewById(R.id.navigation_drawer_nav_view);
        View navView = navigationView.inflateHeaderView(R.layout.navigation_drawer_header);
        NavDrawerProfileImage = navView.findViewById(R.id.navigation_drawer_user_profile_logo);
        NavDrawerProfileUsername = navView.findViewById(R.id.navigation_drawer_user_name);

        NavDrawerProfileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ShowProfilePopUpDialog();
            }
        });

        UserRef.child(currentUserID).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){

                    if(dataSnapshot.hasChild("fullname")){
                        String fullname = dataSnapshot.child("fullname").getValue().toString();
                        NavDrawerProfileUsername.setText(fullname);
                        popUpDialogFullName.setText(fullname);

                    }
                    if(dataSnapshot.hasChild("profileimage")){
                        final String profileimage = dataSnapshot.child("profileimage").getValue().toString();
                        Picasso.with(UserHome.this).load(profileimage)
                                .networkPolicy(NetworkPolicy.OFFLINE)
                                .placeholder(R.drawable.easy_to_use).into(NavDrawerProfileImage, new
                                Callback() {
                                    @Override
                                    public void onSuccess() {

                                    }

                                    @Override
                                    public void onError() {

                                        Picasso.with(UserHome.this).load(profileimage).placeholder(R.drawable.easy_to_use).into(NavDrawerProfileImage);

                                    }
                                });
                        Picasso.with(UserHome.this).load(profileimage)
                                .networkPolicy(NetworkPolicy.OFFLINE)
                                .placeholder(R.drawable.easy_to_use).into(PopupProfileImage, new
                                Callback() {
                                    @Override
                                    public void onSuccess() {

                                    }

                                    @Override
                                    public void onError() {

                                        Picasso.with(UserHome.this).load(profileimage).placeholder(R.drawable.easy_to_use).into(PopupProfileImage);

                                    }
                                });
                    }
                    if(dataSnapshot.hasChild("school")){
                        String school = dataSnapshot.child("school").getValue().toString();
                        PopUpDialogschool.setText("School: " + school);

                    }

                    if(dataSnapshot.hasChild("interestedin")){
                        String interestedin = dataSnapshot.child("interestedin").getValue().toString();
                        PopUpDialogInterestedIn.setText("Interested in: " + interestedin);

                    }

                    if(dataSnapshot.hasChild("profilestatus")){
                        String status = dataSnapshot.child("profilestatus").getValue().toString();
                        popUpdialog_status.setText("Status: " + status);

                    }

                     }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        PostsRef.orderByChild("uid")
                .startAt(currentUserID).endAt(currentUserID + "\uf8ff")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                        if(dataSnapshot.exists()){

                            countPosts = (int)dataSnapshot.getChildrenCount();
                            VideoPostsRef.orderByChild("uid")
                                    .startAt(currentUserID).endAt(currentUserID + "\uf8ff")
                                    .addValueEventListener(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                            if(dataSnapshot.exists()){
                                                countVideoPosts = (int)dataSnapshot.getChildrenCount();
                                                int total_posts = countVideoPosts + countPosts;

                                                no_of_posts.setText(Integer.toString(total_posts));
                                            }
                                        }

                                        @Override
                                        public void onCancelled(@NonNull DatabaseError databaseError) {

                                        }
                                    });
                        }
                        else {

                            no_of_posts.setText("0");
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

        feedsFragment = new FeedsFragment();
        postsFragment = new PostsFragment();
        messagesFragment = new MessagesFragment();
        friendsFragment = new FriendsFragment();
        requestsFragment = new RequestsFragment();

        setFragment(feedsFragment);

        //bottom navigation on selected item listener
        mMainNav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {

                    case R.id.nav_feeds :
                        setFragment(feedsFragment); //loads the feeds Fragment
                        return true;

                    case R.id.nav_posts :
                        setFragment(postsFragment); //loads the posts Fragment
                        return true;

                    case R.id.nav_messages :
                        setFragment(messagesFragment); //loads the messages Fragment
                        return true;

                    case R.id.nav_friends :

                        setFragment(friendsFragment); //loads the friends Fragment
                        return true;

                    case R.id.nav_requests :
                        setFragment(requestsFragment); //loads the requests Fragment
                        return true;

                    default:
                        return false;
                }
            }


        }
        );



        //navigation view on selected item listener
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                userMenuSelector(menuItem);
                return false;
            }
        });

    }

    public void ShowProfilePopUpDialog(){



        textClosDialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                profilePopupDialog.dismiss();
            }
        });
        profilePopupDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        profilePopupDialog.show();
    }

    public void updateUserStatus(String state){
        String saveCurrentDate, saveCurrentTime;

        Calendar calForDate = Calendar.getInstance();
        SimpleDateFormat currentDate = new SimpleDateFormat("MMM dd");
        saveCurrentDate = currentDate.format(calForDate.getTime());

        Calendar calForTime = Calendar.getInstance();
        SimpleDateFormat currentTime = new SimpleDateFormat("hh:mm a");
        saveCurrentTime = currentTime.format(calForTime.getTime());

        Map currentStateMap = new HashMap();
        currentStateMap.put("time", saveCurrentTime);
        currentStateMap.put("date", saveCurrentDate);
        currentStateMap.put("type", state);

        UserRef.child(currentUserID).child("userState").updateChildren(currentStateMap);
        UserRef.child(currentUserID).child("status").setValue(state);

    }

    @Override
    protected void onStart() {
        super.onStart();

        updateUserStatus("Online");
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if(currentUser == null){
            //send user to login activity
            sendUserToLoginActivity();
        }
        else {

            checkUserExistence();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateUserStatus("Online");
        checkformessages();
    }

    @Override
    protected void onPause() {
        super.onPause();
        updateUserStatus("Offline");
    }

    @Override
    public void onStop() {
        super.onStop();
        updateUserStatus("Offline");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        updateUserStatus("Offline");

    }


private void checkformessages(){
    DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference();
    rootRef.addListenerForSingleValueEvent(new ValueEventListener() {
        @Override
        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

            if(dataSnapshot.hasChild("Messages")){
                final DatabaseReference currentuserFriend = FirebaseDatabase.getInstance().getReference().child("Messages");

                currentuserFriend.child(currentUserID).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                        int unread = 0;
                        for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                            final String key_one = snapshot.getKey();
                            for(DataSnapshot snapshot1 : dataSnapshot.child(key_one).getChildren()) {
                                MessagesModel messagesModel = snapshot1.getValue(MessagesModel.class);
                                String to = messagesModel.getTo();
                                boolean isseen = messagesModel.isIsseen();
                                if(to.equals(currentUserID) && !isseen){
                                    unread++;

                                    if(unread == 0){

                                        no_of_unread_messages.setVisibility(View.GONE);

                                    }else {

                                        no_of_unread_messages.setText("new");
                                    }
                                }



                            }


                        }



                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

            }
        }

        @Override
        public void onCancelled(@NonNull DatabaseError databaseError) {

        }
    });
}



    private void checkUserExistence() {
     final String current_user_id = mAuth.getCurrentUser().getUid();
      UserRef.child(current_user_id).addValueEventListener(new ValueEventListener() {
          @Override
          public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
              if(dataSnapshot.exists()){

                  if( (!dataSnapshot.hasChild("fullname")) || (!dataSnapshot.hasChild("username")) ||
                          (!dataSnapshot.hasChild("school")) ){
                      sendUserToSetupActivity();

                  }

              }


          }

          @Override
          public void onCancelled(@NonNull DatabaseError databaseError) {

          }
      });
    }


    private void sendUserToSetupActivity() {
        Intent send_to_setup_activity  = new Intent(UserHome.this, RegisterSetup.class);
        ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(UserHome.this);
        startActivity(send_to_setup_activity, options.toBundle());
        finish();
    }

    private void sendUserToLoginActivity() {
        Intent loginIntent = new Intent(getApplicationContext(),Login.class);
        startActivity(loginIntent);
        finish();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(actionBarDrawerToggle.onOptionsItemSelected(item)){
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    private void userMenuSelector(MenuItem menuItem) {
        switch (menuItem.getItemId()){

            case R.id.nav_drawer_profile:
                // start intent to profile activity
                Intent dialog_to_profile = new Intent(UserHome.this, Profile.class);
                final  String PostToProfileKey = "userhomeprofiledialogtoprofileactivity";
                dialog_to_profile.putExtra("PostToProfile", PostToProfileKey);
                ActivityOptions optionss = ActivityOptions.makeSceneTransitionAnimation(UserHome.this);
                startActivity(dialog_to_profile, optionss.toBundle());
                break;

            case R.id.nav_drawer_my_posts:
                //start the my posts intent
                Intent allMyPostsIntent = new Intent(UserHome.this, AllMyPosts.class);
                ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(UserHome.this);
                startActivity(allMyPostsIntent, options.toBundle());
                break;

            case R.id.nav_drawer_group:
                //start the group intent
                //for now display a toast
                successToast();
                break;

            case R.id.nav_drawer_settings:
                //start the settings intent
                Intent settingsIntent = new Intent(getApplicationContext(), Settings.class);
                ActivityOptions optionst = ActivityOptions.makeSceneTransitionAnimation(UserHome.this);
                startActivity(settingsIntent, optionst.toBundle());
                break;

            case R.id.nav_drawer_logout:
                Map<String, Object> tokenMap = new HashMap<>();
                tokenMap.put("token_id", FieldValue.delete());
                firebaseFirestore.collection("Users").document(currentUserID).update(tokenMap);
                updateUserStatus("Offline");
                mAuth.signOut();
                sendUserToLoginActivity();

                break;
        }
    }

    private void successToast(){
        Toasty.success(this,"Sign Up Successful", Toasty.LENGTH_LONG, true).show();
    }
    private void setFragment(Fragment fragment) {
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.main_frame, fragment);
        fragmentTransaction.commit();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}
