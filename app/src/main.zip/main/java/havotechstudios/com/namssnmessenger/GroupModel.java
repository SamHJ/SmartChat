package havotechstudios.com.namssnmessenger;

public class GroupModel {
    String groupimage, groupname, groupdescription, datecreated, timecreated;

    public GroupModel(){
        //default empty constructor
    }
    public GroupModel(String groupimage, String groupname, String groupdescription, String groupimage1, String datecreated, String timecreated) {
        this.groupimage = groupimage;
        this.groupname = groupname;
        this.groupdescription = groupdescription;
        this.groupimage = groupimage1;
        this.datecreated = datecreated;
        this.timecreated = timecreated;
    }

    public String getGroupimage() {
        return groupimage;
    }

    public void setGroupimage(String groupimage) {
        this.groupimage = groupimage;
    }

    public String getGroupname() {
        return groupname;
    }

    public void setGroupname(String groupname) {
        this.groupname = groupname;
    }

    public String getGroupdescription() {
        return groupdescription;
    }

    public void setGroupdescription(String groupdescription) {
        this.groupdescription = groupdescription;
    }

    public String getDatecreated() {
        return datecreated;
    }

    public void setDatecreated(String datecreated) {
        this.datecreated = datecreated;
    }

    public String getTimecreated() {
        return timecreated;
    }

    public void setTimecreated(String timecreated) {
        this.timecreated = timecreated;
    }
}
