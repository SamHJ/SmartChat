package havotechstudios.com.namssnmessenger;

public class MessagesFragmentModel {

    private String user_status;

    public MessagesFragmentModel(){

    }

    public MessagesFragmentModel(String user_status) {
        this.user_status = user_status;
    }

    public String getUser_status() {
        return user_status;
    }

    public void setUser_status(String user_status) {
        this.user_status = user_status;
    }
}
