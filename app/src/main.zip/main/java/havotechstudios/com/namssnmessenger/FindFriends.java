package havotechstudios.com.namssnmessenger;

import android.app.ActivityOptions;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Pair;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.squareup.picasso.Callback;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;

public class FindFriends extends AppCompatActivity {
Toolbar mToolbar;
ImageButton search_friends_btn;
EditText input_search_query;
RecyclerView display_find_friends_recyclerview;
DatabaseReference allUsersRef;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_friends);

        allUsersRef = FirebaseDatabase.getInstance().getReference().child("Users");
        allUsersRef.keepSynced(true);

        mToolbar = findViewById(R.id.find_friends_toolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setTitle("Find Friends");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//        getSupportActionBar().setDisplayShowCustomEnabled(true);

        //init views
        search_friends_btn = findViewById(R.id.btn_search_friends);
        input_search_query = findViewById(R.id.search_friends_edit_text);
        display_find_friends_recyclerview = findViewById(R.id.search_results_recyclerview);
        display_find_friends_recyclerview.setHasFixedSize(true);
        display_find_friends_recyclerview.setLayoutManager(new LinearLayoutManager(this));

        search_friends_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String searchBoxInput = input_search_query.getText().toString();
                searchForFriends(searchBoxInput);
            }
        });


        DisplayAllUsers();
    }

    private void DisplayAllUsers() {


        FirebaseRecyclerAdapter<FindFriendsModel, FindFriendsviewHolder> firebaseRecyclerAdapter =
                new FirebaseRecyclerAdapter<FindFriendsModel, FindFriendsviewHolder>
                        (
                                FindFriendsModel.class,
                                R.layout.all_friends_display_layout,
                                FindFriendsviewHolder.class,
                                allUsersRef

                        ) {
                    @Override
                    protected void populateViewHolder(final FindFriendsviewHolder viewHolder, FindFriendsModel model, final int position) {

                        viewHolder.setFullname(model.getFullname());
                        viewHolder.setUsername(model.getUsername());
                        viewHolder.setUserschool(model.getUserschool());
                        viewHolder.setProfileimage(getApplicationContext(), model.getProfileimage());

                        viewHolder.mView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                String visit_user_id = getRef(position).getKey();
                                Intent viewUserDetailsIntent = new Intent(FindFriends.this, PersonProfile.class);
                                viewUserDetailsIntent.putExtra("visit_user_id", visit_user_id);

                                Pair[] pairs = new Pair[2];
                                pairs[0] = new Pair<View, String>(viewHolder.userprofileimage, "sharedProfileImageTransition");
                                pairs[1] = new Pair<View, String>(viewHolder.userfullname, "sharedProfileTextTransition");
                                ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(FindFriends.this, pairs);
                                startActivity(viewUserDetailsIntent, options.toBundle());
                            }
                        });

                    }
                };
        display_find_friends_recyclerview.setAdapter(firebaseRecyclerAdapter);

    }

    private void searchForFriends(String searchBoxInput) {

        Query findusersSearchQuery = allUsersRef.orderByChild("fullname")
                .startAt(searchBoxInput).endAt(searchBoxInput + "\uf8ff");

        FirebaseRecyclerAdapter<FindFriendsModel, FindFriendsviewHolder> firebaseRecyclerAdapter =
                new FirebaseRecyclerAdapter<FindFriendsModel, FindFriendsviewHolder>
                        (
                                FindFriendsModel.class,
                                R.layout.all_friends_display_layout,
                                FindFriendsviewHolder.class,
                                findusersSearchQuery

                        ) {
                    @Override
                    protected void populateViewHolder(final FindFriendsviewHolder viewHolder, FindFriendsModel model, final int position) {

                        viewHolder.setFullname(model.getFullname());
                        viewHolder.setUsername(model.getUsername());
                        viewHolder.setUserschool(model.getUserschool());
                        viewHolder.setProfileimage(getApplicationContext(), model.getProfileimage());

                        viewHolder.mView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                String visit_user_id = getRef(position).getKey();
                                Intent viewUserDetailsIntent = new Intent(FindFriends.this, PersonProfile.class);
                                viewUserDetailsIntent.putExtra("visit_user_id", visit_user_id);
                                Pair[] pairs = new Pair[2];
                                pairs[0] = new Pair<View, String>(viewHolder.userprofileimage, "sharedProfileImageTransition");
                                pairs[1] = new Pair<View, String>(viewHolder.userfullname, "sharedProfileTextTransition");
                                ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(FindFriends.this, pairs);
                                startActivity(viewUserDetailsIntent, options.toBundle());
                            }
                        });

                    }
                };
        display_find_friends_recyclerview.setAdapter(firebaseRecyclerAdapter);

    }

    public static class FindFriendsviewHolder extends RecyclerView.ViewHolder {
        View mView;
        final CircleImageView userprofileimage;
        TextView userfullname;
        public FindFriendsviewHolder(@NonNull View itemView) {
            super(itemView);
            this.mView = itemView;
            userprofileimage = mView.findViewById(R.id.search_all_users_profile_image);
            userfullname = mView.findViewById(R.id.search_all_users_profile_name);
        }

        public void setProfileimage(final Context ctx, final String profileimage){
            Picasso.with(ctx).load(profileimage).
            networkPolicy(NetworkPolicy.OFFLINE).placeholder(R.drawable.easy_to_use).into(userprofileimage
                    , new Callback() {
                        @Override
                        public void onSuccess() {

                        }

                        @Override
                        public void onError() {

                            Picasso.with(ctx).load(profileimage).placeholder(R.drawable.easy_to_use).into(userprofileimage);
                        }
                    });
        }

        public void setFullname(String fullname) {
            userfullname.setText(fullname);
        }

        public void setUsername(String username) {
            TextView user_name = mView.findViewById(R.id.search_all_users_profile_username);
            user_name.setText("@" + username);
        }

        public void setUserschool(String school) {
            TextView user_school = mView.findViewById(R.id.search_all_users_profile_school);
            user_school.setText("From " + school);
        }
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if(id == android.R.id.home){
           finish();

        }
        return super.onOptionsItemSelected(item);
    }
}
