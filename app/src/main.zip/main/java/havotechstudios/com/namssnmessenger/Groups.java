package havotechstudios.com.namssnmessenger;

import android.app.ActivityOptions;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Callback;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import de.hdodenhof.circleimageview.CircleImageView;
import es.dmoral.toasty.Toasty;
import havotechstudios.com.namssnmessenger.core.ImageCompressTask;
import havotechstudios.com.namssnmessenger.listeners.IImageCompressTaskListener;

public class Groups extends AppCompatActivity {

    FloatingActionButton addNewGroupFab;
    Toolbar toolbar;
    RecyclerView list_view;
    DatabaseReference groupsRef;
    FirebaseAuth mAuth;
    String currentUserID;
    


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_groups);
        mAuth = FirebaseAuth.getInstance();
        currentUserID = mAuth.getCurrentUser().getUid();

        groupsRef = FirebaseDatabase.getInstance().getReference().child("Groups").child(currentUserID);
        groupsRef.keepSynced(true);

        toolbar = findViewById(R.id.all_groups_appbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle("Groups");
        list_view = findViewById(R.id.all_groups_recyclerview);
        list_view.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext());
        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);
        list_view.setLayoutManager(linearLayoutManager);

        addNewGroupFab = findViewById(R.id.add_new_group_fab);

        addNewGroupFab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AddGroupNameAndDesc();
            }
        });

        DisplayAllGroups();
    }


    private void DisplayAllGroups() {


            FirebaseRecyclerAdapter<GroupModel, GroupViewHolder> firebaseRecyclerAdapter = new
                    FirebaseRecyclerAdapter<GroupModel, GroupViewHolder>
                            (
                                    GroupModel.class,
                                    R.layout.all_groups_display_layout,
                                    GroupViewHolder.class,
                                    groupsRef
                            )
                    {
                        @Override
                        protected void populateViewHolder(final GroupViewHolder viewHolder, final GroupModel model, int position) {



                            final String usersIDs = getRef(position).getKey();
                            groupsRef.addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                                    if(dataSnapshot.exists()){

                                        viewHolder.setGroupimage(getApplicationContext(), model.getGroupimage());
                                        viewHolder.setGroupname(model.getGroupname());
                                        String no_of_partcipants = Integer.toString((int)dataSnapshot.child("Users").getChildrenCount());
                                        viewHolder.no_of_participants_in_group.setText(no_of_partcipants +" participants");

                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {

                                }
                            });
                        }
                    };

            list_view.setAdapter(firebaseRecyclerAdapter);
        }

        public static class GroupViewHolder extends RecyclerView.ViewHolder {
            TextView no_of_participants_in_group;
            View mView;

            public GroupViewHolder(@NonNull View itemView) {
                super(itemView);
                mView = itemView;
                no_of_participants_in_group = mView.findViewById(R.id.no_of_participants_in_group);
            }

            public void setGroupimage(final Context ctx, final String groupimage){
                final CircleImageView group_image = mView.findViewById(R.id.group_image);
                Picasso.with(ctx).load(groupimage).networkPolicy(NetworkPolicy.OFFLINE).placeholder(R.drawable.easy_to_use)
                        .into(group_image, new Callback() {
                            @Override
                            public void onSuccess() {

                            }

                            @Override
                            public void onError() {

                                Picasso.with(ctx).load(groupimage).placeholder(R.drawable.easy_to_use).into(group_image);
                            }
                        });
            }

            public void setGroupname(String groupname) {
                TextView group_name = mView.findViewById(R.id.group_name);
                group_name.setText(groupname);
            }


//            public void setDate(String date) {
//                TextView friends_date = mView.findViewById(R.id.search_all_users_profile_school);
//                friends_date.setText("Friends since " + date);
//            }


        }


//        groupsRef.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//                mGroups.clear();
////                Iterator iterator = dataSnapshot.getChildren().iterator();
//                GroupModel groupModel = dataSnapshot.getValue(GroupModel.class);
//
//                mGroups.add(groupModel);
//                while (iterator.hasNext()){
//
//                    String Messages = (String) ((DataSnapshot)iterator.next()).getValue();
//                    String Users = (String) ((DataSnapshot)iterator.next()).getValue();
//                    String datecreated = (String) ((DataSnapshot)iterator.next()).getValue();
//                    String groupdescription = (String) ((DataSnapshot)iterator.next()).getValue();
//                    String groupname = (String) ((DataSnapshot)iterator.next()).getValue();
//                    String timecreated = (String) ((DataSnapshot)iterator.next()).getValue();
//
//
//                }


//                groupsAdapter = new GroupsAdapter(getApplicationContext(), mGroups);
//                list_view.setAdapter(groupsAdapter);
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError databaseError) {
//
//            }
//        });




    public void AddGroupNameAndDesc() {

        //before inflating the custom alert dialog layout, we will get the current activity viewgroup
        ViewGroup viewGroup = findViewById(android.R.id.content);

        //then we will inflate the custom alert dialog xml that we created
        View dialogView = LayoutInflater.from(Groups.this).inflate(R.layout.custom_group_details, viewGroup, false);


        //Now we need an AlertDialog.Builder object
        android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(Groups.this);

        //setting the view of the builder to our custom view that we already inflated
        builder.setView(dialogView);

        //finally creating the alert dialog and displaying it
        final android.support.v7.app.AlertDialog alertDialog = builder.create();

        Button cancel_btn =  dialogView.findViewById(R.id.cancel_btn);
        Button publish_btn = dialogView.findViewById(R.id.proceed_btn);
        final EditText group_name = dialogView.findViewById(R.id.group_name);
        final EditText group_description = dialogView.findViewById(R.id.group_description);


        publish_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String gname = group_name.getText().toString();
                String gdesc = group_description.getText().toString();

                if(gname.isEmpty() || gname.equals(" ") || gname.equals("  ") || gname.equals("   ")
                        || gname.equals("    ") || gname.equals("     ") || gname.equals("      ") || gdesc.isEmpty() || gdesc.equals(" ") || gdesc.equals("  ") || gdesc.equals("   ")
                        || gdesc.equals("    ") || gdesc.equals("     ") || gdesc.equals("      "))
                {
                    Toasty.error(getApplicationContext(), "No group name or description is specified!", Toasty.LENGTH_SHORT).show();

                }else {

                    Intent add_group_itent = new Intent(getApplicationContext(), AddNewGroup.class);
                    add_group_itent.putExtra("user_group_name", gname);
                    add_group_itent.putExtra("user_group_description", gdesc);
                    ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(Groups.this);
                    startActivity(add_group_itent, options.toBundle());
                    alertDialog.dismiss();
                }


            }
        });

        // if the cancel button is clicked, close the success dialog
        cancel_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });

        alertDialog.show();


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if(id == android.R.id.home){
           finishAfterTransition();
        }
        return super.onOptionsItemSelected(item);
    }
}
