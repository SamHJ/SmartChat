package havotechstudios.com.namssnmessenger;

import android.app.ActivityOptions;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Pair;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.VideoView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Callback;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Locale;

import de.hdodenhof.circleimageview.CircleImageView;

public class AllMyPosts extends AppCompatActivity {

    Toolbar mToolbar;
    RecyclerView postsList, videoPostsList;
    FirebaseAuth mAuth;
    DatabaseReference PostsRef, LikesRef, videopostsRef;
    String currentUserID;
    Boolean LikeChecker = false;
    com.github.clans.fab.FloatingActionButton AddNewPostFab, AddNewVideoPost, ViewVideoPostFab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_my_posts);

        mToolbar = findViewById(R.id.all_my_posts_toolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle("My Posts");

        mAuth = FirebaseAuth.getInstance();
        currentUserID = mAuth.getCurrentUser().getUid();
        PostsRef = FirebaseDatabase.getInstance().getReference().child("Posts");
        PostsRef.keepSynced(true);
        LikesRef = FirebaseDatabase.getInstance().getReference().child("Likes");
        LikesRef.keepSynced(true);
        videopostsRef = FirebaseDatabase.getInstance().getReference().child("VideoPosts");
        videopostsRef.keepSynced(true);


        //used for the all my posts recycler view
        postsList = findViewById(R.id.all_my_posts_lists);
        postsList.setHasFixedSize(true);
        videoPostsList = findViewById(R.id.all_users_video_posts_lists);
        videoPostsList.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);
        postsList.setLayoutManager(linearLayoutManager);
        videoPostsList.setVisibility(View.GONE);


        AddNewPostFab = findViewById(R.id.add_post_fab);
        AddNewPostFab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openAddNewPostActivity();
            }
        });
        AddNewVideoPost = findViewById(R.id.add_video_post_fab);
        AddNewVideoPost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAddNewVideoPostActivity();
            }
        });

        ViewVideoPostFab = findViewById(R.id.view_video_post_fab);
        ViewVideoPostFab.setLabelText("View video posts");

        ViewVideoPostFab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                postsList.setVisibility(View.GONE);
                videoPostsList.setVisibility(View.VISIBLE);
                ViewVideoPostFab.setLabelText("View image posts");

                if(ViewVideoPostFab.getLabelText().equals("View image posts")){
                    ViewVideoPostFab.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            postsList.setVisibility(View.VISIBLE);
                            videoPostsList.setVisibility(View.GONE);
                            ViewVideoPostFab.setLabelText("View video posts");



                            if(ViewVideoPostFab.getLabelText().equals("View video posts")){
                                ViewVideoPostFab.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        postsList.setVisibility(View.GONE);
                                        videoPostsList.setVisibility(View.VISIBLE);
                                        ViewVideoPostFab.setLabelText("View image posts");

                                        if (ViewVideoPostFab.getLabelText().equals("View image posts")) {
                                            ViewVideoPostFab.setOnClickListener(new View.OnClickListener() {
                                                @Override
                                                public void onClick(View v) {
                                                    postsList.setVisibility(View.VISIBLE);
                                                    videoPostsList.setVisibility(View.GONE);
                                                    ViewVideoPostFab.setLabelText("View video posts");

                                                    if(ViewVideoPostFab.getLabelText().equals("View video posts")){
                                                        ViewVideoPostFab.setOnClickListener(new View.OnClickListener() {
                                                            @Override
                                                            public void onClick(View v) {
                                                                postsList.setVisibility(View.GONE);
                                                                videoPostsList.setVisibility(View.VISIBLE);
                                                                ViewVideoPostFab.setLabelText("View image posts");

                                                                if (ViewVideoPostFab.getLabelText().equals("View image posts")) {
                                                                    ViewVideoPostFab.setOnClickListener(new View.OnClickListener() {
                                                                        @Override
                                                                        public void onClick(View v) {
                                                                            postsList.setVisibility(View.VISIBLE);
                                                                            videoPostsList.setVisibility(View.GONE);
                                                                            ViewVideoPostFab.setLabelText("View video posts");

                                                                        } });
                                                                }

                                                            } });
                                                    }
                                                }
                                            });
                                        }
                                    }

                                });
                            }
                        }

                    });
                }


            }
        });


        DisplayAllMyPosts();
        displayAllUsersVideoPosts();
    }



    private void displayAllUsersVideoPosts() {

        Query SortPostsInDecendingOrder = videopostsRef.orderByChild("counter");


        FirebaseRecyclerAdapter<PostsVideo, AllMyPosts.VideoPostsViewHolder> firebaseRecyclerAdapter =
                new FirebaseRecyclerAdapter<PostsVideo, AllMyPosts.VideoPostsViewHolder>
                        (PostsVideo.class,R.layout.all_video_post_layout,AllMyPosts.VideoPostsViewHolder.class, SortPostsInDecendingOrder) {
                    @Override
                    protected void populateViewHolder(final AllMyPosts.VideoPostsViewHolder viewHolder, PostsVideo model, int position) {

                        final String PostKey = getRef(position).getKey();


                        viewHolder.setFullname(model.getFullname());
                        viewHolder.setDate(model.getDate());
                        viewHolder.setDescription(model.getDescription());
                        viewHolder.setTime(model.getTime());
                        viewHolder.setTitle(model.getTitle());
                        viewHolder.setPostvideo(AllMyPosts.this,model.getPostvideo());
                        viewHolder.setProfileimage(AllMyPosts.this, model.getProfileimage());

                        viewHolder.setLikeButtonStatus(PostKey);
                        viewHolder.setNoOfComments(PostKey);

                        viewHolder.mView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Intent postClickintent = new Intent(AllMyPosts.this, PostVideoDetails.class);
                                postClickintent.putExtra("PostKey", PostKey);
                                Pair[] pairs = new Pair[2];
                                pairs[0] = new Pair<View, String>(viewHolder.videoView, "sharedVideoView");
                                pairs[1] = new Pair<View, String>(viewHolder.userimage, "sharedProfileImage");
                                ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(AllMyPosts.this, pairs);
                                startActivity(postClickintent, options.toBundle());
                            }
                        });


                        viewHolder.download_a_post.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {

                                videopostsRef.child(PostKey).addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        if(dataSnapshot.exists()){
                                            String postImage = dataSnapshot.child("postvideo").getValue().toString();

                                            String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
                                                    .format(System.currentTimeMillis());

                                            File root = Environment.getExternalStorageDirectory();
                                            root.mkdirs();
                                            String path = root.toString();

                                            downloadPostImage(AllMyPosts.this, timestamp
                                                    , ".mp4", path + "/NAMSSN MESSENGER" + "/Post Videos" ,
                                                    postImage);
                                        }

                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {

                                    }
                                });

                            }
                        });

                        viewHolder.comment_on_a_post.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Intent postcomment = new Intent(AllMyPosts.this, PostVideoDetails.class);
                                postcomment.putExtra("PostKey", PostKey);
                                Pair[] pairs = new Pair[2];
                                pairs[0] = new Pair<View, String>(viewHolder.videoView, "sharedVideoView");
                                pairs[1] = new Pair<View, String>(viewHolder.userimage, "sharedProfileImage");
                                ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(AllMyPosts.this, pairs);
                                startActivity(postcomment, options.toBundle());
                            }
                        });

                        viewHolder.like_a_post_button.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {

                                LikeChecker = true;

                                LikesRef.addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                                        if(LikeChecker.equals(true)){
                                            if(dataSnapshot.child(PostKey).hasChild(currentUserID)){
                                                LikesRef.child(PostKey).child(currentUserID).removeValue();
                                                LikeChecker = false;
                                            }
                                            else{

                                                LikesRef.child(PostKey).child(currentUserID).setValue(true);
                                                LikeChecker = false;
                                            }
                                        }
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {

                                    }
                                });
                            }
                        });


                    }
                };

        videoPostsList.setAdapter(firebaseRecyclerAdapter);
    }

    public static class VideoPostsViewHolder extends RecyclerView.ViewHolder{
        View mView;

        ImageButton like_a_post_button, comment_on_a_post, download_a_post;
        TextView no_of_post_likes, no_of_post_comments;
        final VideoView videoView;


        int countLikes, commentsCount;
        String currentuser_id;
        DatabaseReference LikesRef;
        MediaController mediaController;
        final CircleImageView userimage;






        public VideoPostsViewHolder(@NonNull View itemView) {
            super(itemView);
            mView = itemView;


            videoView = mView.findViewById(R.id.post_video);
            like_a_post_button = mView.findViewById(R.id.like_a_post);
            comment_on_a_post = mView.findViewById(R.id.comment_on_post);
            download_a_post = mView.findViewById(R.id.download_post_image);


            userimage = mView.findViewById(R.id.user_post_profile_image);
            no_of_post_likes = mView.findViewById(R.id.number_of_likes_textView);
            no_of_post_comments = mView.findViewById(R.id.no_of_comments_textView);

            LikesRef = FirebaseDatabase.getInstance().getReference().child("Likes");
            currentuser_id = FirebaseAuth.getInstance().getCurrentUser().getUid();
        }

        public void setNoOfComments(final String PostKey) {

            DatabaseReference CommentsPostsRef;
            CommentsPostsRef = FirebaseDatabase.getInstance().getReference().child("VideoPosts").child(PostKey).child("Comments");

            CommentsPostsRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    dataSnapshot.getKey();
                    commentsCount  = (int)dataSnapshot.getChildrenCount();
                    no_of_post_comments.setText(commentsCount + " Comments");

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {


                }
            });

        }

        public void setLikeButtonStatus(final String PostKey){
            LikesRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    if(dataSnapshot.child(PostKey).hasChild(currentuser_id)){
                        countLikes = (int) dataSnapshot.child(PostKey).getChildrenCount();
                        like_a_post_button.setImageResource(R.drawable.ic_liked);
                        no_of_post_likes.setText((Integer.toString(countLikes)) + (" Likes"));
                    }
                    else {
                        countLikes = (int) dataSnapshot.child(PostKey).getChildrenCount();
                        like_a_post_button.setImageResource(R.drawable.ic_like);
                        no_of_post_likes.setText((Integer.toString(countLikes)) + (" Likes"));
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }

        public void setFullname(String fullname){
            TextView username = mView.findViewById(R.id.post_username);
            username.setText(fullname);
        }
        public void setPostvideo(final Context ctx, final String postvideo){

            LinearLayout controls_layout;
            controls_layout = mView.findViewById(R.id.controls_layout);
            controls_layout.setVisibility(View.GONE);


            final ProgressBar loading_video_progress_bar = mView.findViewById(R.id.loading_video_progress_bar);

            videoView.setVideoURI(Uri.parse(postvideo));
            videoView.requestFocus();
            videoView.setBackgroundColor(ctx.getResources().getColor(R.color.default_video_post_bg));





            videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {



                @Override
                public void onPrepared(MediaPlayer mp) {

                    mp.setOnVideoSizeChangedListener(new MediaPlayer.OnVideoSizeChangedListener() {
                        @Override
                        public void onVideoSizeChanged(MediaPlayer mp, int width, int height) {
                            mediaController = new MediaController(ctx);
                            videoView.setMediaController(mediaController);
                            mediaController.setAnchorView(videoView);
                        }
                    });


                    mp.setOnInfoListener(new MediaPlayer.OnInfoListener() {
                        @Override
                        public boolean onInfo(MediaPlayer mp, int what, int extra) {
                            if(what == mp.MEDIA_INFO_BUFFERING_END){
                                loading_video_progress_bar.setVisibility(View.INVISIBLE);
                                return true;
                            }
                            else if(what == mp.MEDIA_INFO_BUFFERING_START){
                                loading_video_progress_bar.setVisibility(View.VISIBLE);
                            }
                            return false;
                        }
                    });

                    videoView.start();
                    videoView.setBackgroundColor(0);
                    loading_video_progress_bar.setVisibility(View.INVISIBLE);


                    videoView.seekTo(videoView.getCurrentPosition());
                    if(videoView.getCurrentPosition() != 0){
                        videoView.start();

                    }else {
                        videoView.pause();
                    }


                }
            });




        }
        public void setProfileimage(final Context ctx, final String profileimage){
            Picasso.with(ctx).load(profileimage).networkPolicy(NetworkPolicy.OFFLINE)
                    .into(userimage, new Callback() {
                        @Override
                        public void onSuccess() {

                        }

                        @Override
                        public void onError() {

                            Picasso.with(ctx).load(profileimage).into(userimage);
                        }
                    });
        }
        public void setTime(String time){
            TextView PostTime = mView.findViewById(R.id.post_time);
            PostTime.setText(time);
        }
        public void setDate(String date){
            TextView PostDate = mView.findViewById(R.id.post_date);
            PostDate.setText(date + " at ");
        }
        public void setTitle(String title){
            TextView PostTitle = mView.findViewById(R.id.post_title);
            PostTitle.setText(title);
        }
        public void setDescription(String description){
            TextView PostDescription = mView.findViewById(R.id.post_description);
            PostDescription.setText(description);
        }



    }


    private void DisplayAllMyPosts() {
        Query SortPostsInDecendingOrder = PostsRef.orderByChild("uid")
                .startAt(currentUserID).endAt(currentUserID + "\uf8ff");


        FirebaseRecyclerAdapter<Posts, MyPostsViewHolder> firebaseRecyclerAdapter =
                new FirebaseRecyclerAdapter<Posts, MyPostsViewHolder>
                        (Posts.class,R.layout.all_posts_layout,MyPostsViewHolder.class, SortPostsInDecendingOrder) {
                    @Override
                    protected void populateViewHolder(final MyPostsViewHolder viewHolder, Posts model, int position) {

                        final String PostKey = getRef(position).getKey();


                        viewHolder.setFullname(model.getFullname());
                        viewHolder.setDate(model.getDate());
                        viewHolder.setDescription(model.getDescription());
                        viewHolder.setTime(model.getTime());
                        viewHolder.setTitle(model.getTitle());
                        viewHolder.setPostimage(AllMyPosts.this,model.getPostimage());
                        viewHolder.setProfileimage(AllMyPosts.this, model.getProfileimage());

                        viewHolder.setLikeButtonStatus(PostKey);
                        viewHolder.setNoOfComments(PostKey);

                        viewHolder.mView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Intent postClickintent = new Intent(AllMyPosts.this, PostDetail.class);
                                postClickintent.putExtra("PostKey", PostKey);

                                Pair[] pairs = new Pair[2];
                                pairs[0] = new Pair<View, String>(viewHolder.postImage, "sharedPostImage");
                                pairs[1] = new Pair<View, String>(viewHolder.userimage, "sharedProfileImage");
                                ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(AllMyPosts.this, pairs);
                                startActivity(postClickintent, options.toBundle());
                            }
                        });

                        viewHolder.comment_on_a_post.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Intent postcomment = new Intent(AllMyPosts.this, PostDetail.class);
                                postcomment.putExtra("PostKey", PostKey);
                                Pair[] pairs = new Pair[2];
                                pairs[0] = new Pair<View, String>(viewHolder.postImage, "sharedPostImage");
                                pairs[1] = new Pair<View, String>(viewHolder.userimage, "sharedProfileImage");
                                ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(AllMyPosts.this, pairs);
                                startActivity(postcomment, options.toBundle());
                            }
                        });

                        viewHolder.like_a_post_button.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {

                                LikeChecker = true;

                                LikesRef.addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                                        if(LikeChecker.equals(true)){
                                            if(dataSnapshot.child(PostKey).hasChild(currentUserID)){
                                                LikesRef.child(PostKey).child(currentUserID).removeValue();
                                                LikeChecker = false;
                                            }
                                            else{

                                                LikesRef.child(PostKey).child(currentUserID).setValue(true);
                                                LikeChecker = false;
                                            }
                                        }
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {

                                    }
                                });
                            }
                        });


                    }
                };

        postsList.setAdapter(firebaseRecyclerAdapter);
    }

    public static class MyPostsViewHolder extends RecyclerView.ViewHolder
    {
        View mView;

        ImageButton like_a_post_button, comment_on_a_post, download_a_post;
        TextView no_of_post_likes, no_of_post_comments;

        final ImageView postImage;
        int countLikes, commentsCount;
        String currentuser_id;
        DatabaseReference LikesRef;
        CircleImageView userimage;

        public MyPostsViewHolder(@NonNull View itemView) {
            super(itemView);
            mView = itemView;

             postImage = mView.findViewById(R.id.post_image);
            like_a_post_button = mView.findViewById(R.id.like_a_post);
            comment_on_a_post = mView.findViewById(R.id.comment_on_post);
            download_a_post = mView.findViewById(R.id.download_post_image);

            userimage = mView.findViewById(R.id.user_post_profile_image);
            no_of_post_likes = mView.findViewById(R.id.number_of_likes_textView);
            no_of_post_comments = mView.findViewById(R.id.no_of_comments_textView);

            LikesRef = FirebaseDatabase.getInstance().getReference().child("Likes");
            currentuser_id = FirebaseAuth.getInstance().getCurrentUser().getUid();
        }

        public void setNoOfComments(final String PostKey) {

            DatabaseReference CommentsPostsRef;
            CommentsPostsRef = FirebaseDatabase.getInstance().getReference().child("Posts").child(PostKey).child("Comments");

            CommentsPostsRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    dataSnapshot.getKey();
                    commentsCount  = (int)dataSnapshot.getChildrenCount();
                    no_of_post_comments.setText(commentsCount + " Comments");

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {


                }
            });

        }

        public void setLikeButtonStatus(final String PostKey){
            LikesRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    if(dataSnapshot.child(PostKey).hasChild(currentuser_id)){
                        countLikes = (int) dataSnapshot.child(PostKey).getChildrenCount();
                        like_a_post_button.setImageResource(R.drawable.ic_liked);
                        no_of_post_likes.setText((Integer.toString(countLikes)) + (" Likes"));
                    }
                    else {
                        countLikes = (int) dataSnapshot.child(PostKey).getChildrenCount();
                        like_a_post_button.setImageResource(R.drawable.ic_like);
                        no_of_post_likes.setText((Integer.toString(countLikes)) + (" Likes"));
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }

        public void setFullname(String fullname){
            TextView username = mView.findViewById(R.id.post_username);
            username.setText(fullname);
        }

        public void setProfileimage(Context ctx, String profileimage){
            Picasso.with(ctx).load(profileimage).into(userimage);
        }

        public void setTime(String time){
            TextView PostTime = mView.findViewById(R.id.post_time);
            PostTime.setText(time);
        }

        public void setDate(String date){
            TextView PostDate = mView.findViewById(R.id.post_date);
            PostDate.setText(date + " at ");
        }
        public void setTitle(String title){
            TextView PostTitle = mView.findViewById(R.id.post_title);
            PostTitle.setText(title);
        }
        public void setDescription(String description){
            TextView PostDescription = mView.findViewById(R.id.post_description);
            PostDescription.setText(description);
        }
        public void setPostimage(final Context ctx, final String postimage){

            Picasso.with(ctx).load(postimage).networkPolicy(NetworkPolicy.OFFLINE).placeholder(R.drawable.easy_to_use)
                    .into(postImage, new Callback() {
                @Override
                public void onSuccess() {

                }

                @Override
                public void onError() {

                    Picasso.with(ctx).load(postimage).placeholder(R.drawable.easy_to_use).into(postImage);
                }
            });
        }

    }

    public void downloadPostImage(Context context, String FileName, String FileExtension, String
            DestinationDirectory, String uri){
        DownloadManager downloadManager = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
        Uri uri1 = Uri.parse(uri);
        DownloadManager.Request request = new DownloadManager.Request(uri1);
        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
        request.setDestinationInExternalFilesDir(context, DestinationDirectory, FileName + FileExtension);
        downloadManager.enqueue(request);
    }

    public void openAddNewPostActivity(){
        //open the add new post activity
        Intent addPostIntent = new Intent(AllMyPosts.this ,AddNewPost.class);
        ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(AllMyPosts.this);
        startActivity(addPostIntent, options.toBundle());
//        Snackbar.make(getView(), "Here's a Snackbar", Snackbar.LENGTH_LONG)
//                .setAction("Action", null).show();
    }
    private void openAddNewVideoPostActivity() {
        //open the add new video post activity
        Intent addVideoPostIntent = new Intent(AllMyPosts.this,AddNewVideoPost.class);
        ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(AllMyPosts.this);
        startActivity(addVideoPostIntent, options.toBundle());
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if(id == android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
